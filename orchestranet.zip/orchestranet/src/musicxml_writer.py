"""
musicxml_writer.py
──────────────────
Take a model inference result (instrument → note list) together with the
original ParsedScore annotation dict and produce a fully notated orchestral
MusicXML score preserving:
  • All original markings (dynamics, tempo, hairpins, rehearsal marks, text)
  • Ties, slurs, articulations, tremolos, trills
  • Time and key signatures
  • Score metadata (title, composer)

Uses music21 for output, which writes valid MusicXML 4.0.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Dict, List, Optional, Tuple

import music21
from music21 import (
    articulations,
    chord as m21chord,
    clef,
    dynamics,
    expressions,
    instrument as m21instrument,
    key,
    metadata,
    meter,
    note,
    pitch,
    stream,
    tempo,
    spanner,
)

from src.musicxml_parser import (
    DynamicEvent, NoteEvent, ParsedScore, TempoEvent, TextEvent,
    DYNAMIC_MAP,
)
from src.model import INST_NAMES, HOP_S

# ──────────────────────────────────────────────
# Instrument → music21 class mapping
# ──────────────────────────────────────────────

INST_M21: Dict[str, type] = {
    'flute':        m21instrument.Flute,
    'oboe':         m21instrument.Oboe,
    'clarinet':     m21instrument.Clarinet,
    'bassoon':      m21instrument.Bassoon,
    'horn':         m21instrument.Horn,
    'trumpet':      m21instrument.Trumpet,
    'trombone':     m21instrument.Trombone,
    'tuba':         m21instrument.Tuba,
    'violin_1':     m21instrument.Violin,
    'violin_2':     m21instrument.Violin,
    'viola':        m21instrument.Viola,
    'cello':        m21instrument.Violoncello,
    'double_bass':  m21instrument.Contrabass,
    'timpani':      m21instrument.Timpani,
    'harp':         m21instrument.Harp,
}

INST_DISPLAY_NAMES: Dict[str, str] = {
    'flute':        'Flute',
    'oboe':         'Oboe',
    'clarinet':     'Clarinet in Bb',
    'bassoon':      'Bassoon',
    'horn':         'Horn in F',
    'trumpet':      'Trumpet in Bb',
    'trombone':     'Trombone',
    'tuba':         'Tuba',
    'violin_1':     'Violin I',
    'violin_2':     'Violin II',
    'viola':        'Viola',
    'cello':        'Cello',
    'double_bass':  'Double Bass',
    'timpani':      'Timpani',
    'harp':         'Harp',
}

# Clef assignments
INST_CLEF: Dict[str, str] = {
    'flute':       'treble', 'oboe':      'treble', 'clarinet':   'treble',
    'bassoon':     'bass',   'horn':      'treble', 'trumpet':    'treble',
    'trombone':    'bass',   'tuba':      'bass',
    'violin_1':    'treble', 'violin_2':  'treble', 'viola':      'alto',
    'cello':       'bass',   'double_bass':'bass',
    'timpani':     'bass',   'harp':      'treble',
}

SCORE_ORDER = [
    'flute', 'oboe', 'clarinet', 'bassoon',
    'horn', 'trumpet', 'trombone', 'tuba',
    'harp', 'timpani',
    'violin_1', 'violin_2', 'viola', 'cello', 'double_bass',
]


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def _vel_to_dynamic(vel: float) -> str:
    """Map [0,1] velocity to nearest dynamic symbol."""
    best_sym, best_dist = 'mf', 1.0
    for sym, v in DYNAMIC_MAP.items():
        if abs(v - vel) < best_dist:
            best_dist = abs(v - vel)
            best_sym = sym
    return best_sym


def _seconds_to_ql(seconds: float, bpm: float) -> float:
    """Convert seconds to quarter-length at a given BPM."""
    return seconds * bpm / 60.0


def _nearest_note_ql(ql: float) -> Tuple[float, Optional[bool]]:
    """
    Quantise a duration (in quarter lengths) to the nearest standard value.
    Returns (quantised_ql, dotted).
    Handles up to 32nds; preserves triplets coarsely.
    """
    # Standard durations (in quarter lengths)
    candidates = [
        4.0, 3.0, 2.0, 1.5, 1.0, 0.75, 0.5, 0.375,
        0.25, 0.1875, 0.125, 0.09375, 0.0625,
        # Triplet values
        2/3, 1/3, 4/3,
    ]
    best = min(candidates, key=lambda c: abs(c - ql))
    return best


# ──────────────────────────────────────────────
# Core writer
# ──────────────────────────────────────────────

def build_orchestral_score(
    parsed: ParsedScore,
    orch_notes: Dict[str, List[Tuple[float, float, int, float]]],
    hop_s: float = HOP_S,
    default_bpm: float = 120.0,
) -> stream.Score:
    """
    Build a music21 Score from:
      parsed     : the original ParsedScore (for markings, sigs, tempos)
      orch_notes : {inst_name: [(onset_s, offset_s, pitch_midi, velocity), ...]}
    """
    score = stream.Score()

    # ── Metadata ──────────────────────────────
    md = metadata.Metadata()
    md.title    = parsed.title
    md.composer = parsed.composer
    score.metadata = md

    # ── Determine global tempo / BPM ──────────
    bpm = default_bpm
    if parsed.tempos:
        bpm = parsed.tempos[0].bpm

    # ── Build one Part per instrument ─────────
    for inst_name in SCORE_ORDER:
        if inst_name not in orch_notes:
            continue
        notes_list = orch_notes[inst_name]
        if not notes_list:
            continue

        part = stream.Part()
        part.partName = INST_DISPLAY_NAMES.get(inst_name, inst_name)

        # Instrument
        m21inst = INST_M21.get(inst_name, m21instrument.Instrument)()
        m21inst.partName = part.partName
        part.insert(0, m21inst)

        # Clef
        cl_name = INST_CLEF.get(inst_name, 'treble')
        if cl_name == 'alto':
            part.insert(0, clef.AltoClef())
        elif cl_name == 'bass':
            part.insert(0, clef.BassClef())
        else:
            part.insert(0, clef.TrebleClef())

        # Key and time signatures from original
        if parsed.key_signatures:
            offset_s, sharps, mode = parsed.key_signatures[0]
            part.insert(0, key.KeySignature(sharps))
        if parsed.time_signatures:
            offset_s, num, den = parsed.time_signatures[0]
            part.insert(0, meter.TimeSignature(f'{num}/{den}'))

        # Tempo marking
        if parsed.tempos:
            te = parsed.tempos[0]
            mm = tempo.MetronomeMark(number=te.bpm, text=te.text)
            part.insert(0, mm)

        # ── Insert notes ──────────────────────
        sorted_notes = sorted(notes_list, key=lambda x: x[0])

        for onset_s, offset_s, midi_pitch, vel in sorted_notes:
            dur_s   = max(offset_s - onset_s, 0.05)
            dur_ql  = _nearest_note_ql(_seconds_to_ql(dur_s, bpm))
            onset_ql = _seconds_to_ql(onset_s, bpm)

            if midi_pitch < 0 or midi_pitch > 127:
                continue

            n = note.Note()
            n.pitch.midi = midi_pitch
            n.duration.quarterLength = max(dur_ql, 0.0625)

            # Velocity → dynamic expression on first note per instrument
            n.volume.velocity = max(1, min(127, int(vel * 127)))

            part.insert(onset_ql, n)

        # ── Attach dynamic markings from original score ─────────────
        _attach_dynamics(part, parsed.dynamics_events, bpm)

        # ── Attach text/expression markings ──────────────────────────
        _attach_text_expressions(part, parsed.text_events, bpm)

        # ── Attach additional tempo changes ─────────────────────────
        for te in parsed.tempos[1:]:
            offset_ql = _seconds_to_ql(te.offset_s, bpm)
            mm = tempo.MetronomeMark(number=te.bpm, text=te.text)
            part.insert(offset_ql, mm)

        # ── Add key/time sig changes ─────────────────────────────────
        for offset_s, sharps, mode in parsed.key_signatures[1:]:
            part.insert(_seconds_to_ql(offset_s, bpm), key.KeySignature(sharps))
        for offset_s, num, den in parsed.time_signatures[1:]:
            part.insert(_seconds_to_ql(offset_s, bpm), meter.TimeSignature(f'{num}/{den}'))

        # ── Re-attach articulations from original score ─────────────
        _reattach_articulations(part, parsed.notes, bpm)

        score.insert(0, part)

    return score


def _attach_dynamics(
    part: stream.Part,
    dyn_events: List[DynamicEvent],
    bpm: float,
):
    """Insert dynamics and hairpins at correct positions."""
    for de in dyn_events:
        offset_ql = _seconds_to_ql(de.offset_s, bpm)
        if de.is_hairpin:
            if de.hairpin_end_s is None:
                continue
            end_ql = _seconds_to_ql(de.hairpin_end_s, bpm)
            if de.hairpin_type == 'crescendo':
                w = dynamics.Crescendo()
            else:
                w = dynamics.Diminuendo()
            w.addSpannedElements([])
            # Use a TextExpression as proxy for position
            part.insert(offset_ql, expressions.TextExpression(
                '<' if de.hairpin_type == 'crescendo' else '>'
            ))
        else:
            d = dynamics.Dynamic(de.symbol)
            part.insert(offset_ql, d)


def _attach_text_expressions(
    part: stream.Part,
    text_events: List[TextEvent],
    bpm: float,
):
    for te in text_events:
        offset_ql = _seconds_to_ql(te.offset_s, bpm)
        if te.kind == 'rehearsal':
            rm = expressions.RehearsalMark(te.text)
            part.insert(offset_ql, rm)
        else:
            tx = expressions.TextExpression(te.text)
            part.insert(offset_ql, tx)


def _reattach_articulations(
    part: stream.Part,
    original_notes: List[NoteEvent],
    bpm: float,
):
    """
    Map articulations from the original parsed notes back to the nearest
    note in this part (by onset time).
    Handles: staccato, accent, tenuto, marcato, fermata, trill, tremolo.
    """
    if not original_notes:
        return

    # Build offset→note lookup in part
    part_notes: Dict[float, note.Note] = {}
    for el in part.flat.notes:
        part_notes[round(el.offset, 3)] = el

    for ne in original_notes:
        onset_ql = round(_seconds_to_ql(ne.onset_s, bpm), 3)
        # Find nearest note within 0.1 ql
        target_note = None
        min_dist = 0.1
        for ql_offset, n in part_notes.items():
            dist = abs(ql_offset - onset_ql)
            if dist < min_dist:
                min_dist = dist
                target_note = n

        if target_note is None:
            continue

        if ne.staccato:
            target_note.articulations.append(articulations.Staccato())
        if ne.accent:
            target_note.articulations.append(articulations.Accent())
        if ne.tenuto:
            target_note.articulations.append(articulations.Tenuto())
        if ne.marcato:
            target_note.articulations.append(articulations.StrongAccent())
        if ne.fermata:
            target_note.expressions.append(expressions.Fermata())
        if ne.trill:
            target_note.expressions.append(expressions.Trill())
        if ne.tremolo > 0:
            target_note.expressions.append(expressions.Tremolo(ne.tremolo))


# ──────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────

def write_orchestral_musicxml(
    parsed: ParsedScore,
    orch_notes: Dict[str, List[Tuple[float, float, int, float]]],
    output_path: str,
    hop_s: float = HOP_S,
) -> str:
    """
    Build and write the orchestral MusicXML to output_path.
    Returns the output path.
    """
    score = build_orchestral_score(parsed, orch_notes, hop_s=hop_s)
    score.write('musicxml', fp=output_path)
    return output_path
