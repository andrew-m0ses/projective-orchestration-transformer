"""
musicxml_parser.py
──────────────────
Parse an arbitrary MusicXML file (hyper-complex: nested tuplets, slurs, staccati,
accents, tempo markings, text, dynamics, ties, crescendo/diminuendo, etc.) into:
  1. A dense piano-roll feature tensor  (T, 128)  matching the LOP feature format
  2. A rich annotation dict that will be re-attached to the orchestral output

music21 is used for full MusicXML fidelity.
"""
from __future__ import annotations

import dataclasses
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from music21 import (
    articulations,
    chord as m21chord,
    converter,
    dynamics,
    expressions,
    instrument,
    note,
    stream,
    tempo,
    spanner,
)


# ──────────────────────────────────────────────
# Data containers
# ──────────────────────────────────────────────

@dataclasses.dataclass
class NoteEvent:
    """One sounding note, with every musical parameter we can extract."""
    onset_s: float          # absolute start time in seconds
    offset_s: float         # absolute end time in seconds
    pitch_midi: int         # MIDI pitch 0-127
    velocity: float         # normalised 0-1  (from dynamic context)
    
    # articulations & ornaments (preserve through orchestration)
    staccato: bool = False
    accent: bool = False
    tenuto: bool = False
    marcato: bool = False
    fermata: bool = False
    trill: bool = False
    tremolo: int = 0        # 0 = none, else number of strokes
    
    # spanners (index references, resolved later)
    slur_start: bool = False
    slur_stop: bool = False
    slur_id: Optional[int] = None
    tie_start: bool = False
    tie_stop: bool = False
    
    # tuplet info
    tuplet_actual: Optional[int] = None   # e.g. 3 in triplet
    tuplet_normal: Optional[int] = None   # e.g. 2 in triplet


@dataclasses.dataclass
class TempoEvent:
    offset_s: float
    bpm: float
    text: Optional[str] = None


@dataclasses.dataclass
class DynamicEvent:
    offset_s: float
    value: float            # normalised 0-1
    symbol: str             # 'p', 'f', 'mp', 'mf', 'ff', etc.
    is_hairpin: bool = False
    hairpin_type: Optional[str] = None  # 'crescendo' / 'diminuendo'
    hairpin_end_s: Optional[float] = None


@dataclasses.dataclass
class TextEvent:
    offset_s: float
    text: str
    kind: str = 'expression'   # 'expression' | 'rehearsal' | 'lyrics' | 'tempo'


@dataclasses.dataclass
class ParsedScore:
    """Complete parsed representation of a MusicXML score."""
    title: str
    composer: str
    
    notes: List[NoteEvent]
    tempos: List[TempoEvent]
    dynamics_events: List[DynamicEvent]
    text_events: List[TextEvent]
    
    duration_s: float
    time_signatures: List[Tuple[float, int, int]]   # (offset_s, numerator, denominator)
    key_signatures: List[Tuple[float, int, str]]    # (offset_s, sharps, mode)
    
    # Raw music21 score (kept for MusicXML re-generation)
    m21_score: Any = dataclasses.field(repr=False, default=None)


# ──────────────────────────────────────────────
# Dynamic → velocity mapping
# ──────────────────────────────────────────────

DYNAMIC_MAP: Dict[str, float] = {
    'pppp': 0.05, 'ppp': 0.10, 'pp': 0.18, 'p': 0.28,
    'mp': 0.42, 'mf': 0.55, 'f': 0.70, 'ff': 0.84,
    'fff': 0.92, 'ffff': 0.98, 'sfz': 0.90, 'sfp': 0.80,
    'rfz': 0.85, 'fp': 0.75,
}

DEFAULT_VELOCITY = 0.55   # mf


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def _offset_to_seconds(el, score) -> float:
    """Convert a music21 element's offset (quarter-note beats) to seconds."""
    try:
        return float(score.flat.getOffsetBySite(score.flat) 
                     if False else el.getOffsetBySite(score.flat)) / 1.0
    except Exception:
        return float(el.offset)


def _get_seconds(el, m21_score) -> float:
    try:
        return el.seconds
    except Exception:
        try:
            return float(el.offset) * 0.5   # fallback: assume ♩=120
        except Exception:
            return 0.0


def _note_seconds(n, m21_score) -> Tuple[float, float]:
    """Return (onset_s, offset_s) for a note/chord note."""
    try:
        onset = n.getOffsetInHierarchy(m21_score) * (60.0 / 120.0)
    except Exception:
        onset = float(n.offset) * 0.5
    
    dur_s = n.duration.quarterLength * 0.5
    return onset, onset + dur_s


def _score_to_seconds(m21_score) -> float:
    """Total duration in seconds using tempo map."""
    try:
        return m21_score.seconds
    except Exception:
        return m21_score.flat.highestTime * 0.5


# ──────────────────────────────────────────────
# Main parser
# ──────────────────────────────────────────────

def parse_musicxml(path: str) -> ParsedScore:
    """
    Parse a MusicXML file into a ParsedScore.
    Handles: all tuplets, slurs, ties, staccati, accents, tenuto, marcato,
    fermatas, trills, tremolos, tempo marks, text expressions, dynamics,
    crescendo/diminuendo hairpins, key/time signatures.
    """
    m21_score = converter.parse(path)
    m21_score = m21_score.toSoundingPitch()   # normalise transposing instruments

    title = _extract_metadata(m21_score, 'title') or 'Untitled'
    composer = _extract_metadata(m21_score, 'composer') or 'Unknown'

    flat = m21_score.flat

    # ── Tempo map ──────────────────────────────
    tempo_events = _extract_tempos(m21_score)
    tempo_map = _build_tempo_map(tempo_events, m21_score)

    # ── Dynamic map ───────────────────────────
    dyn_events = _extract_dynamics(m21_score, tempo_map)

    # ── Text events ───────────────────────────
    text_events = _extract_text(m21_score, tempo_map)

    # ── Time / Key sigs ───────────────────────
    time_sigs = _extract_time_sigs(m21_score, tempo_map)
    key_sigs = _extract_key_sigs(m21_score, tempo_map)

    # ── Notes ─────────────────────────────────
    note_events = _extract_notes(m21_score, tempo_map, dyn_events)

    duration_s = _score_to_seconds(m21_score)

    return ParsedScore(
        title=title,
        composer=composer,
        notes=note_events,
        tempos=tempo_events,
        dynamics_events=dyn_events,
        text_events=text_events,
        duration_s=duration_s,
        time_signatures=time_sigs,
        key_signatures=key_sigs,
        m21_score=m21_score,
    )


# ──────────────────────────────────────────────
# Sub-extractors
# ──────────────────────────────────────────────

def _extract_metadata(score, key: str) -> Optional[str]:
    try:
        md = score.metadata
        return getattr(md, key, None)
    except Exception:
        return None


def _extract_tempos(m21_score) -> List[TempoEvent]:
    events: List[TempoEvent] = []
    for el in m21_score.flat.getElementsByClass([tempo.MetronomeMark, tempo.TempoIndication]):
        try:
            offset_ql = float(el.offset)
            bpm = float(el.number) if hasattr(el, 'number') and el.number else 120.0
            text = el.text if hasattr(el, 'text') else None
            events.append(TempoEvent(offset_s=offset_ql, bpm=bpm, text=text))
        except Exception:
            pass
    if not events:
        events.append(TempoEvent(offset_s=0.0, bpm=120.0, text=None))
    return sorted(events, key=lambda e: e.offset_s)


def _build_tempo_map(tempo_events: List[TempoEvent], m21_score) -> List[Tuple[float, float, float]]:
    """
    Returns list of (offset_ql_start, offset_ql_end, seconds_per_beat).
    Used to convert quarter-length offsets to seconds.
    """
    total_ql = float(m21_score.flat.highestTime)
    segments = []
    for i, te in enumerate(tempo_events):
        start_ql = te.offset_s   # stored as ql before we convert
        end_ql = tempo_events[i+1].offset_s if i+1 < len(tempo_events) else total_ql + 100
        spb = 60.0 / max(te.bpm, 1.0)
        segments.append((start_ql, end_ql, spb))
    return segments


def _ql_to_seconds(offset_ql: float, tempo_map: List[Tuple[float, float, float]]) -> float:
    s = 0.0
    for start, end, spb in tempo_map:
        if offset_ql <= start:
            break
        covered = min(offset_ql, end) - start
        s += covered * spb
        if offset_ql <= end:
            break
    return s


def _extract_dynamics(m21_score, tempo_map) -> List[DynamicEvent]:
    events: List[DynamicEvent] = []
    
    for el in m21_score.flat.getElementsByClass(dynamics.Dynamic):
        offset_ql = float(el.offset)
        offset_s = _ql_to_seconds(offset_ql, tempo_map)
        sym = el.value or 'mf'
        vel = DYNAMIC_MAP.get(sym.lower(), DEFAULT_VELOCITY)
        events.append(DynamicEvent(offset_s=offset_s, value=vel, symbol=sym))

    for el in m21_score.flat.getElementsByClass(dynamics.DynamicWedge):
        offset_ql = float(el.offset)
        offset_s = _ql_to_seconds(offset_ql, tempo_map)
        end_ql = offset_ql + float(el.duration.quarterLength)
        end_s = _ql_to_seconds(end_ql, tempo_map)
        htype = 'crescendo' if isinstance(el, dynamics.Crescendo) else 'diminuendo'
        events.append(DynamicEvent(
            offset_s=offset_s, value=DEFAULT_VELOCITY, symbol=htype,
            is_hairpin=True, hairpin_type=htype, hairpin_end_s=end_s
        ))

    return sorted(events, key=lambda e: e.offset_s)


def _extract_text(m21_score, tempo_map) -> List[TextEvent]:
    events: List[TextEvent] = []
    for el in m21_score.flat.getElementsByClass(expressions.TextExpression):
        offset_ql = float(el.offset)
        offset_s = _ql_to_seconds(offset_ql, tempo_map)
        events.append(TextEvent(offset_s=offset_s, text=el.content or '', kind='expression'))
    for el in m21_score.flat.getElementsByClass(expressions.RehearsalMark):
        offset_ql = float(el.offset)
        offset_s = _ql_to_seconds(offset_ql, tempo_map)
        events.append(TextEvent(offset_s=offset_s, text=el.content or '', kind='rehearsal'))
    return sorted(events, key=lambda e: e.offset_s)


def _extract_time_sigs(m21_score, tempo_map):
    from music21 import meter
    result = []
    for ts in m21_score.flat.getElementsByClass(meter.TimeSignature):
        offset_ql = float(ts.offset)
        offset_s = _ql_to_seconds(offset_ql, tempo_map)
        result.append((offset_s, ts.numerator, ts.denominator))
    return result


def _extract_key_sigs(m21_score, tempo_map):
    from music21 import key
    result = []
    for ks in m21_score.flat.getElementsByClass(key.KeySignature):
        offset_ql = float(ks.offset)
        offset_s = _ql_to_seconds(offset_ql, tempo_map)
        sharps = ks.sharps
        mode = ks.mode if hasattr(ks, 'mode') and ks.mode else 'major'
        result.append((offset_s, sharps, mode))
    return result


def _get_active_velocity(offset_s: float, dyn_events: List[DynamicEvent]) -> float:
    vel = DEFAULT_VELOCITY
    for de in dyn_events:
        if de.offset_s > offset_s:
            break
        if not de.is_hairpin:
            vel = de.value
    return vel


def _extract_notes(m21_score, tempo_map, dyn_events: List[DynamicEvent]) -> List[NoteEvent]:
    note_events: List[NoteEvent] = []

    # Collect all slur spanners for lookup
    slur_map: Dict[int, List] = {}
    for s in m21_score.flat.getElementsByClass(spanner.Slur):
        for idx, comp in enumerate(s):
            sid = id(s)
            if sid not in slur_map:
                slur_map[sid] = []
            slur_map[sid].append((idx, id(comp)))

    slur_first: set = set()
    slur_last: set = set()
    for sid, entries in slur_map.items():
        if entries:
            slur_first.add(entries[0][1])
            slur_last.add(entries[-1][1])

    def _process_note(n, is_chord_member=False):
        """Extract one note's full metadata."""
        offset_ql = float(n.offset)
        onset_s = _ql_to_seconds(offset_ql, tempo_map)
        dur_ql = float(n.duration.quarterLength)
        offset_s = _ql_to_seconds(offset_ql + dur_ql, tempo_map)

        vel = _get_active_velocity(onset_s, dyn_events)
        # override with note-level velocity if set
        if hasattr(n, 'volume') and n.volume and n.volume.velocity:
            vel = n.volume.velocity / 127.0

        midi_pitch = n.pitch.midi if hasattr(n, 'pitch') else 60

        # Articulations
        art_types = [type(a).__name__ for a in (n.articulations or [])]
        staccato  = any('Staccato' in a for a in art_types)
        accent    = any('Accent' in a for a in art_types)
        tenuto    = any('Tenuto' in a for a in art_types)
        marcato   = any('Marcato' in a or 'StrongAccent' in a for a in art_types)
        fermata   = any('Fermata' in type(e).__name__ for e in (n.expressions or []))
        trill     = any('Trill' in type(e).__name__ for e in (n.expressions or []))
        tremolo_strokes = 0
        for e in (n.expressions or []):
            if 'Tremolo' in type(e).__name__ and hasattr(e, 'numberOfMarks'):
                tremolo_strokes = e.numberOfMarks or 0

        # Tie
        tie_start = n.tie is not None and n.tie.type in ('start', 'continue')
        tie_stop  = n.tie is not None and n.tie.type in ('stop', 'continue')

        # Slur
        nid = id(n)
        slur_s = nid in slur_first
        slur_e = nid in slur_last

        # Tuplet
        tup_actual = tup_normal = None
        if n.duration.tuplets:
            t = n.duration.tuplets[0]
            tup_actual = t.numberNotesActual
            tup_normal = t.numberNotesNormal

        return NoteEvent(
            onset_s=onset_s,
            offset_s=offset_s,
            pitch_midi=max(0, min(127, midi_pitch)),
            velocity=float(np.clip(vel, 0.0, 1.0)),
            staccato=staccato,
            accent=accent,
            tenuto=tenuto,
            marcato=marcato,
            fermata=fermata,
            trill=trill,
            tremolo=tremolo_strokes,
            slur_start=slur_s,
            slur_stop=slur_e,
            tie_start=tie_start,
            tie_stop=tie_stop,
            tuplet_actual=tup_actual,
            tuplet_normal=tup_normal,
        )

    for el in m21_score.flat.notes:
        if isinstance(el, note.Note):
            note_events.append(_process_note(el))
        elif isinstance(el, m21chord.Chord):
            for n in el.notes:
                ne = _process_note(n)
                # chord shares articulations from the chord object
                chord_arts = [type(a).__name__ for a in (el.articulations or [])]
                ne.staccato  |= any('Staccato' in a for a in chord_arts)
                ne.accent    |= any('Accent'   in a for a in chord_arts)
                ne.tenuto    |= any('Tenuto'   in a for a in chord_arts)
                ne.marcato   |= any('Marcato'  in a or 'StrongAccent' in a for a in chord_arts)
                note_events.append(ne)

    return sorted(note_events, key=lambda n: n.onset_s)


# ──────────────────────────────────────────────
# Pianoroll export (LOP-compatible)
# ──────────────────────────────────────────────

def score_to_pianoroll(parsed: ParsedScore, hop_s: float = 0.05):
    """
    Convert ParsedScore → (T, 128) float32 pianoroll in [0,1] (velocity),
    plus (T, 128) onset binary matrix.
    Matches the LOP piano feature format exactly.
    """
    T = max(1, int(np.ceil(parsed.duration_s / hop_s)))
    roll   = np.zeros((T, 128), dtype=np.float32)
    onset  = np.zeros((T, 128), dtype=np.float32)

    for ne in parsed.notes:
        p = int(ne.pitch_midi)
        if not 0 <= p < 128:
            continue
        f0 = int(np.floor(ne.onset_s  / hop_s))
        f1 = int(np.ceil (ne.offset_s / hop_s))
        f0 = max(0, min(f0, T-1))
        f1 = max(f0+1, min(f1, T))
        roll[f0:f1, p] = np.maximum(roll[f0:f1, p], ne.velocity)
        if f0 < T:
            onset[f0, p] = 1.0

    return roll, onset
