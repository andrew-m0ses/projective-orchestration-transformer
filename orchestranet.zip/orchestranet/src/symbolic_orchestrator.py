"""
symbolic_orchestrator.py
─────────────────────────
Symbolic (frame-free) orchestration pipeline.

Instead of converting to a piano roll and back, we work directly with
music21 note objects. For each note in the input score we ask the model:
"given the local pitch context, which instruments should play this note?"

The model still uses its learned piano-roll representations internally,
but we only use it to produce a per-note instrument probability vector —
we never try to convert frame indices back to durations.

Output: a new music21 Score where each instrument part contains deep-copied
note objects from the original score, preserving ALL notation exactly.
"""
from __future__ import annotations

import copy
from typing import Dict, List, Tuple

import numpy as np
import torch
from music21 import (
    chord as m21chord,
    clef,
    converter,
    key as m21key,
    metadata,
    meter,
    note,
    stream,
    tempo as m21tempo,
    instrument as m21inst,
    dynamics,
    expressions,
    spanner,
)

from src.model import build_model, INST_NAMES, N_ORCH, N_PITCH, INST_RANGE


# ── Instrument setup ──────────────────────────────────────────────────────

INST_M21 = {
    'flute':       m21inst.Flute,
    'oboe':        m21inst.Oboe,
    'clarinet':    m21inst.Clarinet,
    'bassoon':     m21inst.Bassoon,
    'horn':        m21inst.Horn,
    'trumpet':     m21inst.Trumpet,
    'trombone':    m21inst.Trombone,
    'tuba':        m21inst.Tuba,
    'violin_1':    m21inst.Violin,
    'violin_2':    m21inst.Violin,
    'viola':       m21inst.Viola,
    'cello':       m21inst.Violoncello,
    'double_bass': m21inst.Contrabass,
    'timpani':     m21inst.Timpani,
    'harp':        m21inst.Harp,
}

INST_DISPLAY = {
    'flute': 'Flute', 'oboe': 'Oboe', 'clarinet': 'Clarinet in Bb',
    'bassoon': 'Bassoon', 'horn': 'Horn in F', 'trumpet': 'Trumpet in Bb',
    'trombone': 'Trombone', 'tuba': 'Tuba', 'violin_1': 'Violin I',
    'violin_2': 'Violin II', 'viola': 'Viola', 'cello': 'Cello',
    'double_bass': 'Double Bass', 'timpani': 'Timpani', 'harp': 'Harp',
}

SCORE_ORDER = [
    'flute', 'oboe', 'clarinet', 'bassoon',
    'horn', 'trumpet', 'trombone', 'tuba',
    'harp', 'timpani',
    'violin_1', 'violin_2', 'viola', 'cello', 'double_bass',
]


# ── Pitch context window ───────────────────────────────────────────────────

def _build_context_vector(
    active_pitches: List[int],
    context_pitches: List[int],
) -> np.ndarray:
    """
    Build a (128,) pitch presence vector from a set of active pitches.
    active_pitches  : pitches sounding at this exact moment
    context_pitches : pitches from the surrounding window (softer weight)
    """
    vec = np.zeros(128, dtype=np.float32)
    for p in active_pitches:
        if 0 <= p < 128:
            vec[p] = 1.0
    for p in context_pitches:
        if 0 <= p < 128:
            vec[p] = max(vec[p], 0.4)
    return vec


def _get_pitches(el) -> List[int]:
    """Extract MIDI pitches from a note or chord element."""
    if isinstance(el, note.Note):
        return [el.pitch.midi]
    elif isinstance(el, m21chord.Chord):
        return [n.pitch.midi for n in el.notes]
    return []


# ── Model query ───────────────────────────────────────────────────────────

def _query_model(
    model: torch.nn.Module,
    context_vector: np.ndarray,   # (128,) pitch context
    device: torch.device,
    n_frames: int = 16,           # repeat context into short sequence for transformer
) -> np.ndarray:
    """
    Ask the model: given this pitch context, what are the per-(instrument, pitch)
    activation probabilities?

    Returns: (N_ORCH, 128) float32 probability array
    """
    # Expand the single context frame into a short sequence so the transformer
    # has enough context to compute meaningful attention
    roll = np.tile(context_vector, (n_frames, 1))   # (n_frames, 128)
    roll_t = torch.from_numpy(roll).float().unsqueeze(0).to(device)  # (1, n_frames, 128)

    with torch.no_grad():
        logits, _ = model(roll_t)   # (1, n_frames, N_ORCH, 128)

    # Take the middle frame's output as the prediction for this moment
    mid = n_frames // 2
    probs = torch.sigmoid(logits[0, mid]).cpu().numpy()   # (N_ORCH, 128)
    return probs


# ── Main orchestration function ───────────────────────────────────────────

def orchestrate_symbolic(
    xml_path: str,
    model_path: str,
    output_path: str,
    model_size: str = 'base',
    threshold: float = 0.35,
    device_str: str = None,
    context_window: int = 8,      # how many surrounding notes to include as context
) -> str:
    """
    Full symbolic orchestration pipeline.

    1. Parse MusicXML — no frame conversion, work with note objects directly
    2. For each note event, build a local pitch context vector
    3. Query the model once per unique pitch context → per-instrument probabilities
    4. Assign the original note object (deepcopied) to each instrument that fires
    5. Write output MusicXML — all notation preserved exactly
    """

    # ── Load model ────────────────────────────────────────────────────────
    if device_str is None:
        device_str = 'cuda' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device_str)

    print(f'Loading model from {model_path}...')
    model = build_model(model_size)
    ckpt = torch.load(model_path, map_location=device, weights_only=False)
    model.load_state_dict(ckpt.get('model', ckpt))
    model = model.to(device).eval()
    print(f'Model loaded on {device}')

    # ── Parse score ───────────────────────────────────────────────────────
    print(f'Parsing {xml_path}...')
    m21_score = converter.parse(xml_path)
    m21_score = m21_score.toSoundingPitch()

    # Collect ALL note/chord elements with their offsets (in quarter lengths)
    # We work entirely in quarter-length space — no seconds, no frames
    all_elements: List[Tuple[float, object]] = []   # (offset_ql, element)
    for el in m21_score.flatten().notesAndRests:
        if isinstance(el, (note.Note, m21chord.Chord)):
            all_elements.append((float(el.offset), el))

    all_elements.sort(key=lambda x: x[0])
    print(f'Found {len(all_elements)} note/chord elements')

    # Build a flat list of (offset_ql, [pitches]) for context lookup
    offset_pitches: List[Tuple[float, List[int]]] = [
        (off, _get_pitches(el)) for off, el in all_elements
    ]

    # ── For each element, build context and query model ───────────────────
    print('Querying model for each note event...')

    # Cache model queries by pitch-frozenset to avoid redundant calls
    query_cache: Dict[frozenset, np.ndarray] = {}

    # inst_name → list of (offset_ql, element) to insert into that part
    inst_assignments: Dict[str, List[Tuple[float, object]]] = {
        name: [] for name in INST_NAMES
    }

    for idx, (offset_ql, el) in enumerate(all_elements):
        pitches = _get_pitches(el)
        if not pitches:
            continue

        # Build context: current + surrounding notes
        window_start = max(0, idx - context_window)
        window_end   = min(len(offset_pitches), idx + context_window + 1)
        context_pitches = []
        for j in range(window_start, window_end):
            if j != idx:
                context_pitches.extend(offset_pitches[j][1])

        ctx_vec = _build_context_vector(pitches, context_pitches)
        cache_key = frozenset(enumerate(ctx_vec.round(2)))

        if cache_key not in query_cache:
            query_cache[cache_key] = _query_model(model, ctx_vec, device)

        probs = query_cache[cache_key]   # (N_ORCH, 128)

        # For each instrument, check if ANY of this element's pitches fire
        for i_inst, inst_name in enumerate(INST_NAMES):
            inst_lo, inst_hi = INST_RANGE[inst_name]
            fires = False
            for p in pitches:
                if not (inst_lo <= p <= inst_hi):
                    continue   # skip pitches outside instrument range
                if probs[i_inst, p] > threshold:
                    fires = True
                    break
            if fires:
                inst_assignments[inst_name].append((offset_ql, el))

    for name in INST_NAMES:
        print(f'  {name:15s}: {len(inst_assignments[name])} elements')

    # ── Build output score via direct XML assembly ────────────────────────
    import xml.etree.ElementTree as ET_out
    import copy as _copy
    from collections import defaultdict as _dd

    xml_tree = ET_out.parse(xml_path)
    xml_root = xml_tree.getroot()
    xml_part = xml_root.findall('part')[0]

    _div_init = 256
    for _m in xml_part.findall('measure'):
        _d = _m.find('.//divisions')
        if _d is not None: _div_init = int(_d.text); break

    _NOTE_ORDER = ['grace','chord','pitch','unpitched','rest','duration','tie',
                   'instrument','footnote','level','voice','type','dot',
                   'accidental','time-modification','stem','notehead',
                   'notehead-text','staff','beam','notations','lyric','play','listen']

    _STD_AT_256 = [1024,768,512,384,256,192,128,96,64,48,32,24,16]
    _STD_TYPE   = {1024:('whole',0),768:('half',1),512:('half',0),
                   384:('quarter',1),256:('quarter',0),192:('eighth',1),
                   128:('eighth',0),96:('16th',1),64:('16th',0),
                   48:('32nd',1),32:('32nd',0),24:('64th',1),16:('64th',0)}

    def _std_table(div):
        s=div/256; return [(int(round(t*s)),)+_STD_TYPE[t] for t in _STD_AT_256]

    def _fill_rests(ticks, div):
        """Greedy decomposition into standard rests, exact total."""
        if ticks<=0: return []
        table=_std_table(div); result=[]; rem=ticks
        for st,ts,dots in table:
            if st<=0: continue
            while rem>=st: result.append((st,ts,dots)); rem-=st
        if rem>0:
            if result: lt,lts,ld=result[-1]; result[-1]=(lt+rem,lts,ld)
            else: result.append((max(rem,16),'64th',0))
        return result

    def _nearest_std(ticks, div):
        return min(_std_table(div), key=lambda s: abs(s[0]-ticks))

    def _make_rest_el(ticks, type_str, dots, ratio=None):
        """Create a rest element. If ratio=(actual,normal), add time-modification."""
        n=ET_out.Element('note')
        ET_out.SubElement(n,'rest')
        ET_out.SubElement(n,'duration').text=str(ticks)
        ET_out.SubElement(n,'voice').text='1'
        ET_out.SubElement(n,'type').text=type_str
        for _ in range(dots): ET_out.SubElement(n,'dot')
        if ratio is not None:
            tm=ET_out.SubElement(n,'time-modification')
            ET_out.SubElement(tm,'actual-notes').text=ratio[0]
            ET_out.SubElement(tm,'normal-notes').text=ratio[1]
        ET_out.SubElement(n,'staff').text='1'
        return n

    def _make_measure_rest(meas_ticks):
        n=ET_out.Element('note'); r=ET_out.SubElement(n,'rest'); r.set('measure','yes')
        ET_out.SubElement(n,'duration').text=str(meas_ticks)
        ET_out.SubElement(n,'voice').text='1'
        ET_out.SubElement(n,'type').text='whole'
        ET_out.SubElement(n,'staff').text='1'; return n

    def _reorder_note(note_el):
        children=list(note_el)
        note_el[:]=sorted(children,
            key=lambda c:(_NOTE_ORDER.index(c.tag) if c.tag in _NOTE_ORDER else 999))

    def _clean_note(note_el):
        new=_copy.deepcopy(note_el)
        for b in list(new.findall('beam')): new.remove(b)
        for c in list(new.findall('chord')): new.remove(c)
        for s in new.findall('staff'): s.text='1'
        for v in new.findall('voice'): v.text='1'
        _reorder_note(new); return new

    def _fix_attributes(attrs_el, clef_sign, clef_line):
        new=_copy.deepcopy(attrs_el)
        for tag in ('staves','staff-details'):
            for s in list(new.findall(tag)): new.remove(s)
        for c in list(new.findall('clef')): new.remove(c)
        cl=ET_out.SubElement(new,'clef')
        ET_out.SubElement(cl,'sign').text=clef_sign
        ET_out.SubElement(cl,'line').text=clef_line
        return new

    def _xml_pitch_to_midi(note_el):
        if note_el.find('rest') is not None: return None
        step_el=note_el.find('.//step'); oct_el=note_el.find('.//octave')
        alt_el=note_el.find('.//alter')
        if step_el is None or oct_el is None: return None
        sm={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
        midi=(int(oct_el.text)+1)*12+sm.get(step_el.text,0)
        if alt_el is not None: midi+=int(round(float(alt_el.text)))
        return midi

    def _walk_measure(meas, div, ts_num, ts_den):
        pos=0; onset_at_chord=0; result=[]
        for child in meas:
            if child.tag=='attributes':
                ts=child.find('time')
                if ts is not None:
                    ts_num=int(ts.find('beats').text); ts_den=int(ts.find('beat-type').text)
                d=child.find('divisions')
                if d is not None: div=int(d.text)
            elif child.tag=='note':
                grace=child.find('grace'); dur_el=child.find('duration')
                chord_el=child.find('chord'); rest_el=child.find('rest')
                if grace is not None: continue
                if chord_el is None: onset_at_chord=pos
                dur=int(dur_el.text) if dur_el is not None else 0
                tm=child.find('time-modification')
                ratio=None
                if tm is not None:
                    an=tm.find('actual-notes'); nn=tm.find('normal-notes')
                    if an is not None and nn is not None: ratio=(an.text,nn.text)
                result.append({'onset':onset_at_chord,'dur':dur,'midi':_xml_pitch_to_midi(child),
                                'el':child,'is_rest':rest_el is not None,'ratio':ratio,'gid':None})
                if chord_el is None and dur_el is not None: pos+=dur
            elif child.tag=='backup':
                d=child.find('duration')
                if d is not None: pos-=int(d.text)
            elif child.tag=='forward':
                d=child.find('duration')
                if d is not None: pos+=int(d.text)
        meas_ticks=ts_num*div*4//ts_den
        # Assign group IDs: each contiguous run of non-rest notes with same ratio = one group
        _gid=0; _gi=0
        while _gi<len(result):
            _n=result[_gi]
            if _n['is_rest'] or _n['ratio'] is None: _gi+=1; continue
            _r=_n['ratio']; _gj=_gi+1
            while _gj<len(result) and not result[_gj]['is_rest'] and result[_gj]['ratio']==_r: _gj+=1
            for _k in range(_gi,_gj): result[_k]['gid']=_gid
            _gid+=1; _gi=_gj
        return meas_ticks,result,div,ts_num,ts_den

    def _get_ratio(n):
        if n.find('rest') is not None: return None
        tm=n.find('time-modification')
        if tm is None: return None
        an=tm.find('actual-notes'); nn=tm.find('normal-notes')
        return (an.text,nn.text) if an is not None and nn is not None else None

    def _beam_depth(ts):
        return {'eighth':1,'16th':2,'32nd':3,'64th':4,'128th':5}.get(ts,0)

    def _postprocess(note_list, div, ts_den):
        # Pass 1: strip isolated tuplet notes (run of 1)
        i=0
        while i<len(note_list):
            n=note_list[i]
            if _get_ratio(n) is None: i+=1; continue
            r=_get_ratio(n); j=i+1
            while j<len(note_list) and _get_ratio(note_list[j])==r: j+=1
            if j-i==1:
                tm=n.find('time-modification')
                if tm is not None: n.remove(tm)
                dur_el=n.find('duration'); typ_el=n.find('type')
                if dur_el is not None and typ_el is not None:
                    std_t,ts,dots=_nearest_std(int(dur_el.text),div)
                    typ_el.text=ts
                    for d in list(n.findall('dot')): n.remove(d)
                    children=list(n)
                    ti=next((k for k,c in enumerate(children) if c.tag=='type'),len(children)-1)
                    for k in range(dots): d=ET_out.Element('dot'); n.insert(ti+1+k,d)
                nots=n.find('notations')
                if nots is not None:
                    for tup in list(nots.findall('tuplet')): nots.remove(tup)
                    if len(nots)==0: n.remove(nots)
            i=j

        # Pass 2: rebuild tuplet brackets scoped by original group ID
        for n in note_list:
            nots=n.find('notations')
            if nots is not None:
                for tup in list(nots.findall('tuplet')): nots.remove(tup)
                if len(nots)==0: n.remove(nots)
        i=0
        while i<len(note_list):
            n=note_list[i]
            if _get_ratio(n) is None: i+=1; continue
            r=_get_ratio(n)
            gid=n.get('_gid')  # original group ID (may be None for isolated notes)
            j=i+1
            while j<len(note_list):
                nj=note_list[j]
                if _get_ratio(nj)!=r: break
                # Stop if group ID changes (different original tuplet group)
                if nj.get('_gid')!=gid: break
                j+=1
            if j-i>=2:
                for idx,btype in ((i,'start'),(j-1,'stop')):
                    nots=note_list[idx].find('notations')
                    if nots is None: nots=ET_out.Element('notations'); note_list[idx].append(nots)
                    te=ET_out.SubElement(nots,'tuplet')
                    te.set('type',btype); te.set('number','1')
                    te.set('bracket','yes'); te.set('placement','above')
            i=j
        # Strip temporary group ID attributes
        for n in note_list: n.attrib.pop('_gid',None)

        # Pass 3: beams
        beat_ticks=div if ts_den in (4,2) else div//2
        def _beamable(n):
            if n.find('rest') is not None: return False
            t=n.find('type')
            return t is not None and _beam_depth(t.text)>=1
        positions=[]; pos=0
        for n in note_list:
            positions.append(pos)
            d=n.find('duration'); pos+=int(d.text) if d is not None else 0
        def _add_beams(run):
            if len(run)<2: return
            t=run[0].find('type'); depth=_beam_depth(t.text) if t else 1
            for k,nn in enumerate(run):
                val='begin' if k==0 else 'end' if k==len(run)-1 else 'continue'
                for bn in range(1,depth+1):
                    b=ET_out.SubElement(nn,'beam'); b.set('number',str(bn)); b.text=val
        i=0
        while i<len(note_list):
            n=note_list[i]
            if not _beamable(n) or _get_ratio(n) is None: i+=1; continue
            r=_get_ratio(n); j=i+1
            while j<len(note_list) and _beamable(note_list[j]) and _get_ratio(note_list[j])==r: j+=1
            _add_beams(note_list[i:j]); i=j
        i=0
        while i<len(note_list):
            n=note_list[i]
            if not _beamable(n) or _get_ratio(n) is not None: i+=1; continue
            bs=(positions[i]//beat_ticks)*beat_ticks; be=bs+beat_ticks
            j=i+1
            while j<len(note_list) and _beamable(note_list[j]) and _get_ratio(note_list[j]) is None and positions[j]<be: j+=1
            _add_beams(note_list[i:j]); i=j

        for n in note_list:
            if n.find('rest') is None: _reorder_note(n)
        return note_list

    def _build_voice(meas_notes, meas_ticks, assigned_onsets, div, ts_den):
        """Place assigned notes; fill gaps with context-aware rests.
        Gaps WITHIN a tuplet group get tuplet rests (same ratio, exact duration).
        Other gaps get standard rests via greedy decomposition."""

        by_onset=_dd(list)
        for n in meas_notes:
            if n['onset']<meas_ticks: by_onset[n['onset']].append(n)

        # Build a map: onset -> ratio for each unique onset in the original
        onset_ratio={}
        for n in meas_notes:
            if not n['is_rest'] and n['ratio'] is not None:
                onset_ratio[n['onset']]=n['ratio']

        # Build a contiguous ratio coverage map:
        # For each tick position, what ratio covers it (if any)?
        # A ratio covers a position if there's a run of same-ratio notes spanning it.
        ratio_spans=[]  # list of (start_onset, end_onset, ratio)
        i=0
        flat=[n for n in meas_notes if n['onset']<meas_ticks and not n['is_rest']]
        flat.sort(key=lambda n:n['onset'])
        while i<len(flat):
            r=flat[i]['ratio']
            if r is None: i+=1; continue
            j=i+1
            while j<len(flat) and flat[j]['ratio']==r: j+=1
            span_start=flat[i]['onset']
            span_end=flat[j-1]['onset']+flat[j-1]['dur']
            ratio_spans.append((span_start,span_end,r,flat[i]['el']))
            i=j

        def _ratio_for_gap(gap_start, gap_end):
            """Return the ratio if this gap falls entirely within one ratio span."""
            for span_start,span_end,r,template_el in ratio_spans:
                if gap_start>=span_start and gap_end<=span_end:
                    return r, template_el
            return None, None

        # Collect assigned events
        assigned_events=[]
        for onset in sorted(by_onset.keys()):
            group=by_onset[onset]
            hits=[n for n in group if n['midi'] is not None
                  and n['midi'] in assigned_onsets.get(onset,set())]
            if hits:
                n_copy=_clean_note(hits[0]['el'])
                dur_el=n_copy.find('duration')
                orig_dur=int(dur_el.text) if dur_el is not None else 0
                clamped=min(orig_dur,meas_ticks-onset)
                if dur_el is not None: dur_el.text=str(clamped)
                # Tag with original group ID for bracket scoping
                gid=hits[0].get('gid')
                if gid is not None: n_copy.set('_gid',str(gid))
                assigned_events.append((onset,clamped,n_copy))

        if not assigned_events:
            return [_make_measure_rest(meas_ticks)]

        # Build output with context-aware gap filling
        output=[]; cur=0
        for onset,dur,note_el in assigned_events:
            if onset<cur: continue  # overlap, skip
            if onset>cur:
                gap=onset-cur
                ratio,tpl=_ratio_for_gap(cur,onset)
                if ratio is not None:
                    # Fill with tuplet rest(s) matching the ratio
                    # Use same note type as the template
                    typ_el=tpl.find('type')
                    type_str=typ_el.text if typ_el is not None else '32nd'
                    dots_els=tpl.findall('dot')
                    dots=len(dots_els)
                    output.append(_make_rest_el(gap,type_str,dots,ratio))
                else:
                    # Standard rest decomposition
                    for t,ts,d in _fill_rests(gap,div):
                        output.append(_make_rest_el(t,ts,d))
            output.append(note_el); cur=onset+dur

        # Fill tail
        if cur<meas_ticks:
            gap=meas_ticks-cur
            ratio,tpl=_ratio_for_gap(cur,meas_ticks)
            if ratio is not None:
                typ_el=tpl.find('type')
                type_str=typ_el.text if typ_el is not None else '32nd'
                dots=len(tpl.findall('dot'))
                output.append(_make_rest_el(gap,type_str,dots,ratio))
            else:
                for t,ts,d in _fill_rests(gap,div):
                    output.append(_make_rest_el(t,ts,d))

        output=_postprocess(output,div,ts_den)
        return output

    # ── Convert m21 assignments ───────────────────────────────────────────

    _measure_offsets={}
    for _sp in m21_score.parts:
        for _ms in _sp.getElementsByClass(stream.Measure):
            _measure_offsets[_ms.number]=float(_ms.offset)
        break

    def _m21_to_keys(offset_ql, el, inst_name):
        best_mn,best_diff=None,float('inf')
        for mn,moff in _measure_offsets.items():
            diff=offset_ql-moff
            if -0.001<=diff<best_diff: best_diff=diff; best_mn=mn
        if best_mn is None: return []
        onset_ticks=int(round(best_diff*_div_init))
        if isinstance(el,note.Note): raw_pitches=[el.pitch.midi]
        elif isinstance(el,m21chord.Chord): raw_pitches=[n.pitch.midi for n in el.notes]
        else: return []
        lo,hi=INST_RANGE.get(inst_name,(0,127))
        return [(best_mn,onset_ticks,p) for p in raw_pitches if lo<=p<=hi]

    assigned_keys={name:_dd(lambda:_dd(set)) for name in INST_NAMES}
    for inst_name in INST_NAMES:
        for offset_ql,el in inst_assignments[inst_name]:
            for mn,onset_ticks,midi in _m21_to_keys(offset_ql,el,inst_name):
                assigned_keys[inst_name][mn][onset_ticks].add(midi)

    print('\nBuilding orchestral XML...')
    for name in INST_NAMES:
        total=sum(len(s) for d in assigned_keys[name].values() for s in d.values())
        if total: print(f'  {name:15s}: {total} note-keys')

    _INST_CLEF={
        'flute':('G','2'),'oboe':('G','2'),'clarinet':('G','2'),
        'bassoon':('F','4'),'horn':('G','2'),'trumpet':('G','2'),
        'trombone':('F','4'),'tuba':('F','4'),'harp':('G','2'),
        'timpani':('F','4'),'violin_1':('G','2'),'violin_2':('G','2'),
        'viola':('C','3'),'cello':('F','4'),'double_bass':('F','4'),
    }

    score_el=ET_out.Element('score-partwise'); score_el.set('version','3.0')
    work_el=ET_out.SubElement(score_el,'work')
    orig_title=(xml_root.findtext('.//work-title') or xml_root.findtext('.//movement-title') or '')
    ET_out.SubElement(work_el,'work-title').text=orig_title

    part_list_el=ET_out.SubElement(score_el,'part-list')
    part_id_map={}
    for _i,inst_name in enumerate(SCORE_ORDER):
        total=sum(len(s) for d in assigned_keys[inst_name].values() for s in d.values())
        if not total: continue
        pid=f'P{_i+1}'; part_id_map[inst_name]=pid
        sp_el=ET_out.SubElement(part_list_el,'score-part'); sp_el.set('id',pid)
        ET_out.SubElement(sp_el,'part-name').text=INST_DISPLAY.get(inst_name,inst_name)
        si_el=ET_out.SubElement(sp_el,'score-instrument'); si_el.set('id',f'{pid}-I1')
        ET_out.SubElement(si_el,'instrument-name').text=INST_DISPLAY.get(inst_name,inst_name)

    for inst_name in SCORE_ORDER:
        total=sum(len(s) for d in assigned_keys[inst_name].values() for s in d.values())
        if not total: continue
        pid=part_id_map[inst_name]
        clef_sign,clef_line=_INST_CLEF.get(inst_name,('G','2'))
        inst_asgn=assigned_keys[inst_name]

        part_el=ET_out.SubElement(score_el,'part'); part_el.set('id',pid)
        cur_div=_div_init; cur_ts=(2,4)

        for xml_meas in xml_part.findall('measure'):
            mn=int(xml_meas.get('number',0))
            new_meas=ET_out.Element('measure')
            new_meas.set('number',xml_meas.get('number',''))

            meas_ticks,meas_notes,cur_div,ts_n,ts_d=\
                _walk_measure(xml_meas,cur_div,cur_ts[0],cur_ts[1])
            cur_ts=(ts_n,ts_d)

            for child in xml_meas:
                if child.tag=='attributes':
                    new_meas.append(_fix_attributes(child,clef_sign,clef_line))
                elif child.tag=='barline':
                    new_meas.append(_copy.deepcopy(child))

            note_els=_build_voice(meas_notes,meas_ticks,inst_asgn.get(mn,{}),cur_div,ts_d)
            for el in note_els:
                inst_el=el.find('instrument')
                if inst_el is not None: inst_el.set('id',f'{pid}-I1')
                new_meas.append(el)

            part_el.append(new_meas)

    print(f'Writing {output_path}...')
    xmldecl='<?xml version="1.0" encoding="utf-8"?>\n'
    doctype=('<!DOCTYPE score-partwise PUBLIC '
             '"-//Recordare//DTD MusicXML 3.0 Partwise//EN" '
             '"http://www.musicxml.org/dtds/partwise.dtd">\n')
    with open(output_path,'w',encoding='utf-8') as _f:
        _f.write(xmldecl); _f.write(doctype)
        _f.write(ET_out.tostring(score_el,encoding='unicode',xml_declaration=False))
    print(f'✅ Done: {output_path} ({os.path.getsize(output_path)//1000} KB)')
    return output_path


import os
