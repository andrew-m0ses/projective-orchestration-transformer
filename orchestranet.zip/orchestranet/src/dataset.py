"""
dataset.py  (updated)
──────────────────────
PyTorch Dataset loading both original AND augmented LOP piano/orchestra .npz
feature pairs for training.

Handles two index formats:
  - Original:   data/features/meta/features_index.csv
                columns: pair_id, piano_npz, orch_npz
  - Augmented:  data/features/meta/features_index_aug.csv
                columns: pair_id, piano_npz, orch_npz, pitch_shift, vel_scale

Both are loaded and merged into one training pool.
"""
from __future__ import annotations

import random
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

from src.model import INST_NAMES, ORCH_INSTRUMENTS, N_PITCH, N_ORCH


def _build_gm_to_orch() -> np.ndarray:
    table = np.full(129, -1, dtype=np.int32)
    for i, (name, prog) in enumerate(ORCH_INSTRUMENTS.items()):
        table[prog] = i
    if table[72] < 0: table[72] = INST_NAMES.index('flute')
    if table[69] < 0: table[69] = INST_NAMES.index('oboe')
    return table

GM_TO_ORCH = _build_gm_to_orch()


class LOPDataset(Dataset):
    def __init__(
        self,
        manifest_rows: List[dict],
        data_root: Path,
        segment_T: Optional[int] = 512,
        hop_s: float = 0.05,
        augment: bool = True,
    ):
        self.rows = manifest_rows
        self.data_root = Path(data_root)
        self.segment_T = segment_T
        self.hop_s = hop_s
        self.augment = augment

    def __len__(self) -> int:
        return len(self.rows)

    def _resolve_path(self, p: str) -> Path:
        path = Path(p)
        if path.is_absolute():
            return path
        return self.data_root / path

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        row = self.rows[idx]
        piano_path = self._resolve_path(row['piano_npz'])
        orch_path  = self._resolve_path(row['orch_npz'])

        piano_npz = np.load(piano_path, allow_pickle=True)
        orch_npz  = np.load(orch_path)

        piano_roll = piano_npz['roll'].astype(np.float32)
        orch_act   = orch_npz['instrument_activity'].astype(np.float32)

        T = min(piano_roll.shape[0], orch_act.shape[0])
        piano_roll = piano_roll[:T]
        orch_act   = orch_act[:T]

        sparse_t = orch_npz['sparse_t']
        sparse_i = orch_npz['sparse_i']
        sparse_p = orch_npz['sparse_p']
        sparse_v = orch_npz['sparse_v']

        target_acts = np.zeros((T, N_ORCH, N_PITCH), dtype=np.float32)
        target_vels = np.zeros((T, N_ORCH), dtype=np.float32)

        for k in range(len(sparse_t)):
            t_frame = int(sparse_t[k])
            gm_prog = int(sparse_i[k])
            pitch   = int(sparse_p[k])
            vel     = float(sparse_v[k])
            if t_frame >= T:
                continue
            orch_idx = GM_TO_ORCH[min(gm_prog, 128)]
            if orch_idx < 0:
                continue
            if 0 <= pitch < N_PITCH:
                target_acts[t_frame, orch_idx, pitch] = 1.0
                target_vels[t_frame, orch_idx] = max(target_vels[t_frame, orch_idx], vel)

        if self.segment_T is not None and T > self.segment_T:
            start = random.randint(0, T - self.segment_T)
            piano_roll  = piano_roll[start:start + self.segment_T]
            target_acts = target_acts[start:start + self.segment_T]
            target_vels = target_vels[start:start + self.segment_T]

        if self.augment:
            scale = random.uniform(0.92, 1.08)
            piano_roll  = np.clip(piano_roll  * scale, 0.0, 1.0)
            target_vels = np.clip(target_vels * scale, 0.0, 1.0)

        return (
            torch.from_numpy(piano_roll),
            torch.from_numpy(target_acts),
            torch.from_numpy(target_vels),
        )


def pad_collate(batch):
    rolls, acts, vels = zip(*batch)
    T_max = max(r.shape[0] for r in rolls)

    def pad(t):
        pad_len = T_max - t.shape[0]
        if pad_len == 0:
            return t
        shape = list(t.shape); shape[0] = pad_len
        return torch.cat([t, torch.zeros(shape, dtype=t.dtype)], dim=0)

    return (
        torch.stack([pad(r) for r in rolls]),
        torch.stack([pad(a) for a in acts]),
        torch.stack([pad(v) for v in vels]),
    )


def _resolve_npz(path_str: str, data_root: Path) -> Optional[Path]:
    p = Path(path_str)
    if p.is_absolute() and p.exists():
        return p
    rel = data_root / p
    if rel.exists():
        return rel
    return None


def load_manifest(
    data_root: Path,
    split: str = 'train',
    include_augmented: bool = True,
) -> List[dict]:
    """
    Load manifest rows for a split, merging original + augmented pairs.
    Augmented pairs are only added to the 'train' split, never valid/test.
    """
    import pandas as pd
    data_root = Path(data_root)
    rows = []

    # Original pairs
    index_path = data_root / 'data' / 'features' / 'meta' / 'features_index.csv'
    if index_path.exists():
        df = pd.read_csv(index_path)
        split_path = data_root / 'data' / 'processed' / 'splits' / f'{split}.txt'
        if split_path.exists():
            with open(split_path) as f:
                ids = set(line.strip() for line in f if line.strip())
            df = df[df['pair_id'].isin(ids)]
        for _, row in df.iterrows():
            p = _resolve_npz(row['piano_npz'], data_root)
            o = _resolve_npz(row['orch_npz'],  data_root)
            if p and o:
                rows.append({'piano_npz': str(p), 'orch_npz': str(o),
                             'pair_id': row['pair_id']})

    print(f'Original {split} pairs: {len(rows)}')

    # Augmented pairs (train only)
    if include_augmented and split == 'train':
        aug_index = data_root / 'data' / 'features' / 'meta' / 'features_index_aug.csv'
        if aug_index.exists():
            aug_df = pd.read_csv(aug_index)
            train_split_path = data_root / 'data' / 'processed' / 'splits' / 'train.txt'
            if train_split_path.exists() and 'orig_pair_id' in aug_df.columns:
                with open(train_split_path) as f:
                    train_ids = set(line.strip() for line in f if line.strip())
                aug_df = aug_df[aug_df['orig_pair_id'].isin(train_ids)]
            added = 0
            for _, row in aug_df.iterrows():
                p = _resolve_npz(row['piano_npz'], data_root)
                o = _resolve_npz(row['orch_npz'],  data_root)
                if p and o:
                    rows.append({'piano_npz': str(p), 'orch_npz': str(o),
                                 'pair_id': row['pair_id']})
                    added += 1
            print(f'Augmented train pairs added: {added}')
        else:
            print('No augmented index found — run scripts/augment_lop.py first')

    print(f'Total {split} pairs: {len(rows)}')
    return rows
