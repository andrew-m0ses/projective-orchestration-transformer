"""
model.py
────────
Transformer-based piano → orchestral transcription model, designed to be trained
on the LOP (Linked-Parts Orchestration) database.

Architecture overview
─────────────────────
  Input : (B, T, 128)  piano pianoroll, velocity-normalised
  Output: (B, T, 129)  per-instrument velocity logits (128 GM programs + drums)
          plus         (B, T, 128, N_ORCH) instrument-pitch multi-label head

The model uses:
  • Pitch-time patch embedding (stride-8 frames × stride-12 semitones)
  • Causal + non-causal Transformer encoder (non-causal: we process the whole input)
  • Cross-attention over a fixed "orchestral texture" memory bank built from the
    training set statistics
  • Multi-label sigmoid output per (instrument, pitch) pair

Training objective
──────────────────
  Binary cross-entropy on per-(instrument, frame, pitch) activations
  + family-balance auxiliary loss (wood/brass/strings/perc must stay balanced)
  + doubling consistency loss (learned from LOP doubling statistics)

Inference
─────────
  Greedy threshold (t=0.35 default) or beam search over instrument combos.
  Pitch assignment: instruments receive notes from the piano input whose
  register & timbre best match what the model learned for that instrument.
"""

from __future__ import annotations

import math
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

# ──────────────────────────────────────────────
# Constants matching LOP feature schema
# ──────────────────────────────────────────────

N_PITCH      = 128    # MIDI pitch
N_INST       = 129    # 128 GM + drums (as in LOP)
N_FAM        = 17     # GM families (LOP schema)
HOP_S        = 0.05   # seconds per frame (LOP default)

# Orchestral instrument subset used for output (Standard Symphony Orchestra)
# Maps a friendly name → GM program (0-indexed)
ORCH_INSTRUMENTS: Dict[str, int] = {
    # Woodwinds
    'flute':          73,
    'oboe':           68,
    'clarinet':       71,
    'bassoon':        70,
    # Brass
    'horn':           60,
    'trumpet':        56,
    'trombone':       57,
    'tuba':           58,
    # Strings
    'violin_1':       40,
    'violin_2':       40,
    'viola':          41,
    'cello':          42,
    'double_bass':    43,
    # Percussion / other
    'timpani':        47,
    'harp':           46,
}

N_ORCH = len(ORCH_INSTRUMENTS)   # 15 instruments

# Instrument range constraints (MIDI pitch: lo, hi)
INST_RANGE: Dict[str, Tuple[int,int]] = {
    'flute':        (60, 98),
    'oboe':         (58, 91),
    'clarinet':     (50, 94),
    'bassoon':      (34, 72),
    'horn':         (34, 77),
    'trumpet':      (52, 82),
    'trombone':     (40, 72),
    'tuba':         (28, 58),
    'violin_1':     (55, 103),
    'violin_2':     (55, 96),
    'viola':        (48, 91),
    'cello':        (36, 84),
    'double_bass':  (28, 67),
    'timpani':      (40, 65),
    'harp':         (23, 103),
}
INST_NAMES = list(ORCH_INSTRUMENTS.keys())


# ──────────────────────────────────────────────
# Positional encoding
# ──────────────────────────────────────────────

class SinusoidalPE(nn.Module):
    def __init__(self, d_model: int, max_len: int = 8192):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(max_len).unsqueeze(1).float()
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div[:d_model//2])
        self.register_buffer('pe', pe.unsqueeze(0))   # (1, max_len, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, :x.size(1)]


# ──────────────────────────────────────────────
# Piano encoder (time → embedding)
# ──────────────────────────────────────────────

class PianoEncoder(nn.Module):
    """
    Encode a (B, T, 128) pianoroll into (B, T, d_model) contextual embeddings.

    Design:
    • Conv1d temporal context (kernel=3) to capture short-range temporal patterns
    • Linear projection 128 → d_model
    • Multi-head self-attention Transformer
    """

    def __init__(
        self,
        d_model: int = 256,
        n_heads: int = 8,
        n_layers: int = 6,
        dropout: float = 0.1,
        max_T: int = 8192,
    ):
        super().__init__()
        self.d_model = d_model

        # Temporal conv preprocessing
        self.conv = nn.Sequential(
            nn.Conv1d(N_PITCH, d_model, kernel_size=3, padding=1),
            nn.GELU(),
            nn.Conv1d(d_model, d_model, kernel_size=3, padding=1),
            nn.GELU(),
        )

        self.pe = SinusoidalPE(d_model, max_T)
        self.norm_in = nn.LayerNorm(d_model)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * 4,
            dropout=dropout,
            batch_first=True,
            norm_first=True,   # pre-norm
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)

    def forward(self, piano_roll: torch.Tensor) -> torch.Tensor:
        """
        piano_roll: (B, T, 128) float in [0,1]
        returns:    (B, T, d_model)
        """
        B, T, _ = piano_roll.shape
        # Conv: needs (B, C, T) — C = 128 pitch channels
        x = piano_roll.transpose(1, 2)           # (B, 128, T)
        x = self.conv(x).transpose(1, 2)         # (B, T, d_model)
        x = self.pe(x)
        x = self.norm_in(x)
        x = self.transformer(x)                  # (B, T, d_model)
        return x


# ──────────────────────────────────────────────
# Orchestral decoder
# ──────────────────────────────────────────────

class OrchDecoder(nn.Module):
    """
    Cross-attend the piano encoding to produce per-instrument activations.

    For each instrument we maintain a learned query token that cross-attends
    over the piano encoding, producing a per-frame, per-instrument embedding.
    Final head: (B, T, N_ORCH, N_PITCH) → sigmoid → binary activation.
    """

    def __init__(
        self,
        d_model: int = 256,
        n_heads: int = 8,
        n_layers: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model

        # Instrument-specific learned embeddings (queries)
        self.inst_embed = nn.Embedding(N_ORCH, d_model)

        # Cross-attention: each instrument query → attends piano encoding
        cross_layer = nn.TransformerDecoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * 4,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
        )
        self.cross_attn = nn.TransformerDecoder(cross_layer, num_layers=n_layers)

        # Final projection: d_model → N_PITCH logits per instrument
        self.pitch_head = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Linear(d_model, N_PITCH),
        )

        # Velocity head: d_model → scalar velocity per instrument
        self.vel_head = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.Linear(d_model // 2, 1),
            nn.Sigmoid(),
        )

    def forward(
        self,
        piano_enc: torch.Tensor,   # (B, T, d_model)
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns:
          pitch_logits: (B, T, N_ORCH, N_PITCH) — raw logits for sigmoid
          velocities:   (B, T, N_ORCH)           — predicted velocity [0,1]
        """
        B, T, D = piano_enc.shape

        # Create instrument queries: (B*T, N_ORCH, d_model)
        inst_ids  = torch.arange(N_ORCH, device=piano_enc.device)
        inst_q    = self.inst_embed(inst_ids)                        # (N_ORCH, D)
        inst_q    = inst_q.unsqueeze(0).unsqueeze(0)                 # (1, 1, N_ORCH, D)
        inst_q    = inst_q.expand(B, T, N_ORCH, D)                  # (B, T, N_ORCH, D)

        # Reshape for cross-attention: (B*T, N_ORCH, D) queries, (B*T, 1, D) keys
        q = inst_q.view(B*T, N_ORCH, D)
        k = piano_enc.view(B*T, 1, D)   # single frame as memory

        z = self.cross_attn(q, k)        # (B*T, N_ORCH, D)
        z = z.view(B, T, N_ORCH, D)

        pitch_logits = self.pitch_head(z)   # (B, T, N_ORCH, N_PITCH)
        velocities   = self.vel_head(z).squeeze(-1)   # (B, T, N_ORCH)

        return pitch_logits, velocities


# ──────────────────────────────────────────────
# Full model
# ──────────────────────────────────────────────

class OrchestraNet(nn.Module):
    """
    End-to-end piano → orchestra model.

    Training
    ─────────
    forward() returns logits + velocities.
    Use compute_loss() to get the combined training loss.

    Inference
    ─────────
    orchestrate() takes a piano roll, returns a dict mapping
    instrument name → list of (onset_s, offset_s, pitch_midi, velocity).
    """

    def __init__(
        self,
        d_model: int = 256,
        enc_layers: int = 6,
        dec_layers: int = 4,
        n_heads: int = 8,
        dropout: float = 0.1,
        threshold: float = 0.35,
    ):
        super().__init__()
        self.encoder = PianoEncoder(d_model, n_heads, enc_layers, dropout)
        self.decoder = OrchDecoder(d_model, n_heads, dec_layers, dropout)
        self.threshold = threshold

        # Register instrument range masks (not trainable)
        range_mask = torch.zeros(N_ORCH, N_PITCH)
        for i, name in enumerate(INST_NAMES):
            lo, hi = INST_RANGE[name]
            range_mask[i, lo:hi+1] = 1.0
        self.register_buffer('range_mask', range_mask)   # (N_ORCH, N_PITCH)

    def forward(self, piano_roll: torch.Tensor):
        """
        piano_roll: (B, T, 128)
        Returns: pitch_logits (B, T, N_ORCH, 128), velocities (B, T, N_ORCH)
        """
        enc = self.encoder(piano_roll)
        logits, vels = self.decoder(enc)
        # Apply range mask (set out-of-range pitches to very negative logit)
        mask = self.range_mask.unsqueeze(0).unsqueeze(0)   # (1, 1, N_ORCH, N_PITCH)
        logits = logits + (mask - 1.0) * 1e4               # -inf outside range
        return logits, vels

    def compute_loss(
        self,
        piano_roll: torch.Tensor,      # (B, T, 128)
        target_acts: torch.Tensor,     # (B, T, N_ORCH, 128) binary
        target_vels: torch.Tensor,     # (B, T, N_ORCH) float in [0,1]
        family_weights: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Combined loss:
          L_pitch = Focal loss on pitch activations — handles extreme sparsity
                    much better than plain BCE. gamma=2 down-weights easy
                    negatives so the model actually learns to predict positives.
          L_vel   = MSE on velocity of active notes only
        Family balance loss removed — it was fighting against learning by
        pushing predictions toward uniform distribution.
        """
        logits, vels = self.forward(piano_roll)

        # ── Focal loss ────────────────────────────────────────────────────
        # Focal loss = -alpha_t * (1 - p_t)^gamma * log(p_t)
        # For sparse targets: gamma=2 suppresses easy negatives,
        # pos_weight=80 compensates for ~1:80 positive:negative ratio
        # in orchestral pitch activations.
        gamma     = 2.0
        pos_w     = 80.0
        targets_f = target_acts.float()
        probs     = torch.sigmoid(logits)

        # BCE component
        bce = F.binary_cross_entropy_with_logits(
            logits, targets_f,
            pos_weight=torch.tensor(pos_w, device=logits.device),
            reduction='none'
        )
        # Focal weight: (1-p)^gamma for positives, p^gamma for negatives
        p_t         = probs * targets_f + (1 - probs) * (1 - targets_f)
        focal_w     = (1.0 - p_t) ** gamma
        L_pitch     = (focal_w * bce).mean()

        # ── Velocity MSE (only over active target notes) ─────────────────
        active_any = targets_f.max(dim=-1).values   # (B, T, N_ORCH)
        vel_err    = (vels - target_vels) ** 2
        denom      = active_any.sum() + 1e-6
        L_vel      = (vel_err * active_any).sum() / denom

        total = L_pitch + 0.1 * L_vel
        return {
            'loss':       total,
            'loss_pitch': L_pitch,
            'loss_vel':   L_vel,
            'loss_fam':   torch.tensor(0.0),   # kept for API compatibility
        }

    @torch.no_grad()
    def orchestrate(
        self,
        piano_roll: torch.Tensor,    # (T, 128) or (1, T, 128)
        hop_s: float = HOP_S,
        threshold: Optional[float] = None,
    ) -> Dict[str, list]:
        """
        Run inference.
        Returns dict: instrument_name → list of (onset_s, offset_s, pitch_midi, velocity).
        """
        self.eval()
        t = threshold if threshold is not None else self.threshold

        if piano_roll.dim() == 2:
            piano_roll = piano_roll.unsqueeze(0)   # (1, T, 128)

        logits, vels = self.forward(piano_roll)
        probs = torch.sigmoid(logits)    # (1, T, N_ORCH, 128)
        probs = probs.squeeze(0)         # (T, N_ORCH, 128)
        vels  = vels.squeeze(0)          # (T, N_ORCH)

        T = probs.shape[0]
        result: Dict[str, list] = {name: [] for name in INST_NAMES}

        for i_inst, name in enumerate(INST_NAMES):
            act = (probs[:, i_inst, :] > t).cpu().numpy()  # (T, 128)
            vel = vels[:, i_inst].cpu().numpy()             # (T,)

            # Convert frame activations to note events
            for pitch in range(N_PITCH):
                frames = act[:, pitch]
                # find contiguous runs
                in_note = False
                note_start_f = 0
                for f in range(T):
                    if frames[f] and not in_note:
                        in_note = True
                        note_start_f = f
                    elif not frames[f] and in_note:
                        in_note = False
                        onset_s  = note_start_f * hop_s
                        offset_s = f * hop_s
                        v = float(vel[note_start_f:f].mean())
                        result[name].append((onset_s, offset_s, pitch, v))
                if in_note:
                    onset_s  = note_start_f * hop_s
                    offset_s = T * hop_s
                    v = float(vel[note_start_f:].mean())
                    result[name].append((onset_s, T * hop_s, pitch, float(v)))

        return result


# ──────────────────────────────────────────────
# Model factory
# ──────────────────────────────────────────────

def build_model(size: str = 'base') -> OrchestraNet:
    """
    size: 'small' | 'base' | 'large'
    """
    configs = {
        'small': dict(d_model=128, enc_layers=4, dec_layers=3, n_heads=4),
        'base':  dict(d_model=256, enc_layers=6, dec_layers=4, n_heads=8),
        'large': dict(d_model=512, enc_layers=8, dec_layers=6, n_heads=8),
    }
    return OrchestraNet(**configs[size])
