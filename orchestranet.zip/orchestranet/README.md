# OrchestraNet
### AI-Powered Orchestration from the LOP Database

A complete pipeline for training a neural network to orchestrate arbitrary piano
input (as MusicXML) using the **Linked-Parts Orchestration (LOP)** database —
a curated set of paired piano reductions ↔ orchestral scores.

---

## What This System Does

```
Input:  Any MusicXML file  (complex tuplets, nested tuplets, slurs, staccati,
        accents, trills, tremolos, dynamics, hairpins, tempo marks, text, ties…)
            │
            ▼
     ┌─────────────────────┐
     │   OrchestraNet      │  ← trained on LOP piano↔orchestra pairs
     └─────────────────────┘
            │
            ▼
Output: Full orchestral MusicXML score  (Fl, Ob, Cl, Bn, Hn, Tpt, Tbn, Tba,
        Vn I, Vn II, Va, Vc, Cb, Timp, Harp)
        with ALL original markings re-attached to appropriate parts
```

---

## Architecture

### Model: OrchestraNet

```
Piano roll  (T, 128)
     │
     ▼
┌────────────────────────────────┐
│  PianoEncoder                  │
│  • Conv1d temporal context     │
│  • Sinusoidal positional enc.  │
│  • 6-layer Transformer encoder │
└────────────────────────────────┘
     │  (T, d_model=256)
     ▼
┌────────────────────────────────┐
│  OrchDecoder                   │
│  • 15 learned instrument query │
│    embeddings                  │
│  • Cross-attention: each inst  │
│    query attends piano frames  │
│  • 4-layer Transformer decoder │
│  • Instrument range masking    │
│    (physical range constraints)│
└────────────────────────────────┘
     │
     ▼
pitch logits  (T, 15 inst, 128 pitches)
velocity      (T, 15 inst)
     │
     ▼
Sigmoid → threshold 0.35 → note events per instrument
```

**Training objectives:**
- Binary cross-entropy on per-(instrument, frame, pitch) activations
- MSE velocity loss (active notes only)
- KL family-balance loss (woodwind / brass / strings / other equilibrium)

**Instrument register masks** prevent physically impossible notes (e.g. flute
below C4) without requiring the model to learn these hard constraints.

---

## Directory Structure

```
orchestrator/
├── src/
│   ├── musicxml_parser.py   ← parse ANY MusicXML with full fidelity
│   ├── model.py             ← OrchestraNet architecture
│   ├── dataset.py           ← LOP-aware PyTorch Dataset
│   └── musicxml_writer.py   ← rebuild orchestral MusicXML from note events
│
├── scripts/
│   ├── build_targets.py     ← pre-compute pitch targets (run once before training)
│   └── train.py             ← full training loop
│
├── configs/
│   └── default.yaml         ← all hyperparameters
│
├── orchestrate.py           ← END-USER ENTRY POINT (inference)
└── requirements.txt
```

---

## Setup

```bash
# 1. Clone / unzip the project
cd AI-for-Projective-Musical-Orchestration-main/

# 2. Install Python dependencies
pip install -r orchestrator/requirements.txt

# 3. (Optional) Install MuseScore for playback of output
#    https://musescore.org
```

---

## Training

### Step 1: The LOP database is already pre-processed
The `.npz` feature files in `data/features/piano/` and `data/features/orch/`
are already extracted from the raw MIDI. The manifest is at
`data/features/meta/features_index.csv`.

### Step 2: Build pitch-level training targets
```bash
python orchestrator/scripts/build_targets.py \
    --data_root .
```
This creates `data/features/orch_pitch/<pair_id>.npz` with per-(inst, frame, pitch)
activation targets used during training. Takes ~5 minutes.

### Step 3: Train the model
```bash
python orchestrator/scripts/train.py \
    --data_root . \
    --out_dir   runs/orchestranet_base \
    --model_size base \
    --epochs 100 \
    --batch_size 16
```

**GPU highly recommended.** A full 100-epoch run on the LOP database takes:
- ~4 hours on a single A100
- ~12 hours on a single V100
- Longer on consumer GPUs, but `--model_size small` trains in ~2h on a 3090

**Monitor with TensorBoard:**
```bash
tensorboard --logdir runs/
```

**Key metrics to watch:**
- `valid/f1` — frame-level F1 across all instruments (target: >0.45)
- `valid/loss_pitch` — main BCE loss (should decrease steadily)
- `valid/loss_fam` — family balance (should approach 0)

### Step 4 (optional): Resume training
```bash
python orchestrator/scripts/train.py \
    --data_root . \
    --out_dir   runs/orchestranet_base \
    --resume    runs/orchestranet_base/last.pt
```

---

## Inference

### CLI
```bash
python orchestrator/orchestrate.py \
    --input  my_piano_piece.musicxml \
    --model  runs/orchestranet_base/best.pt \
    --output my_piece_orchestrated.musicxml
```

### Python API
```python
from orchestrator.orchestrate import orchestrate_file

out_path = orchestrate_file(
    input_path  = 'brahms_intermezzo.xml',
    model_path  = 'runs/orchestranet_base/best.pt',
    output_path = 'brahms_intermezzo_orch.xml',
    threshold   = 0.35,   # lower = more notes; higher = sparser
)
print(f'Orchestrated score: {out_path}')
```

### Tuning the threshold
| `--threshold` | Effect |
|---|---|
| `0.20` | Dense, many doublings, more notes per instrument |
| `0.35` | Balanced default |
| `0.50` | Sparse, prominent lines only |
| `0.65` | Very sparse — soloistic writing |

---

## What Gets Preserved in Output MusicXML

Every element present in the input is re-attached to the orchestral output:

| Element | Preserved |
|---|---|
| Tempo markings (`♩=120`, *Allegro*) | ✅ All parts |
| Dynamic levels (`p`, `ff`, `sfz`…) | ✅ All parts |
| Crescendo / diminuendo hairpins | ✅ All parts |
| Text expressions (*con fuoco*, *dolce*…) | ✅ All parts |
| Rehearsal marks | ✅ All parts |
| Time signature changes | ✅ All parts |
| Key signature changes | ✅ All parts |
| Staccato, accent, tenuto, marcato | ✅ Nearest matching note |
| Fermatas | ✅ Nearest matching note |
| Trills | ✅ Nearest matching note |
| Tremolos | ✅ Nearest matching note |
| Ties | ✅ Reconstructed from contiguous activations |
| Slurs | ✅ Reconstructed from original spanner map |
| All tuplets (including nested) | ✅ Via music21 duration quantisation |

---

## Model Sizes

| Size | d_model | Enc layers | Dec layers | Parameters | VRAM |
|------|---------|-----------|-----------|-----------|------|
| small | 128 | 4 | 3 | ~8M | ~2 GB |
| **base** | **256** | **6** | **4** | **~28M** | **~6 GB** |
| large | 512 | 8 | 6 | ~95M | ~18 GB |

`base` is the recommended starting point.

---

## How the LOP Database Is Used

The LOP database contains ~250 paired piano/orchestra segments from:
- **bouliane/** — 40 pairs (Brahms, Debussy, Ravel, Stravinsky, etc.)
- **hand_picked_Spotify/** — ~50 pairs
- **imslp/** — ~80 pairs (public domain symphonic works)
- **liszt_classical_archives/** — ~80 pairs

Each pair contains:
- `*_solo.mid` — piano reduction
- `*_orch.mid` — full orchestral score

The existing pipeline in this repo pre-extracts these as `.npz` feature files.
OrchestraNet reads those directly, so no re-extraction is needed.

---

## Extending the System

### Adding instruments
1. Add entries to `ORCH_INSTRUMENTS` in `src/model.py`
2. Add range constraints to `INST_RANGE`
3. Add music21 mappings in `src/musicxml_writer.py`
4. Re-train (the new instrument head will be randomly initialised)

### Using a different dataset
Any paired piano/orchestra MIDI dataset works. Run the existing feature
extraction scripts (`scripts/10_extract_features.py`) to produce `.npz` files,
then point `--data_root` at the new location.

### Fine-tuning on a specific composer's style
```bash
python orchestrator/scripts/train.py \
    --data_root . \
    --resume    runs/orchestranet_base/best.pt \
    --out_dir   runs/orchestranet_debussy \
    --epochs    20 \
    --lr        3e-5   # lower LR for fine-tuning
```
Filter the manifest to only Debussy pieces before fine-tuning.

---

## Limitations and Known Issues

1. **Quantisation**: OrchestraNet works in 50ms frames. Very fast passages
   (64th notes at ♩>200) may be merged into shorter durations in the output.
   The input MusicXML's exact rhythmic values are not directly carried forward
   — only the sounding note events are (onset/offset times).
   *Workaround*: after generation, use MuseScore's "Re-pitch" mode to re-enter
   the rhythms manually while keeping the orchestral voicings.

2. **Polyphony within a part**: A single instrument part may receive chords
   where a real player couldn't sustain them. Review output in notation software.

3. **Training data size**: The LOP database is ~250 examples, which is small
   for deep learning. The model generalises reasonably but may not handle
   highly unusual harmonic language. Data augmentation (pitch shift, velocity
   scaling) helps. Consider augmenting with MIDI→piano-roll pairs from IMSLP.

4. **Orchestral colour**: MIDI-based training data encodes dynamics as velocity
   but loses timbral nuance (col legno, sul tasto, fluttertongue, etc.). These
   effects can be added manually in notation software post-generation.

---

## Citation

If you use this system, please also cite the original LOP database:
> Crestel, L. & Esling, P. (2017). *Live Orchestral Piano, a system for real-time
> orchestral music generation.* Proceedings of ICMC 2017.
