"""
orchestrate.py
──────────────
End-user CLI + Python API:

  CLI:
    python orchestrate.py \
        --input  my_piece.musicxml \
        --model  runs/orchestranet_base/best.pt \
        --output my_piece_orchestrated.musicxml \
        --threshold 0.35

  Python API:
    from orchestrate import orchestrate_file
    out = orchestrate_file('my_piece.xml', model_path='best.pt')

The pipeline is:
  1. Parse input MusicXML → ParsedScore  (music21, full fidelity)
  2. Extract piano roll                   (LOP-compatible, hop=50ms)
  3. Run OrchestraNet inference           (→ per-instrument note events)
  4. Write orchestral MusicXML            (music21, all markings re-attached)
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import Optional

import numpy as np
import torch

# Make project root importable when run as script
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.musicxml_parser import parse_musicxml, score_to_pianoroll
from src.model import OrchestraNet, build_model, HOP_S
from src.musicxml_writer import write_orchestral_musicxml

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s  %(levelname)-8s  %(message)s',
    datefmt='%H:%M:%S',
)
log = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# Load model
# ──────────────────────────────────────────────

def load_model(
    model_path: str,
    model_size: str = 'base',
    device: Optional[str] = None,
) -> OrchestraNet:
    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    dev = torch.device(device)

    model = build_model(model_size)
    ckpt  = torch.load(model_path, map_location=dev, weights_only=False)
    state = ckpt.get('model', ckpt)
    model.load_state_dict(state)
    model = model.to(dev)
    model.eval()
    log.info(f'Loaded model from {model_path}  (size={model_size}, device={dev})')
    return model


# ──────────────────────────────────────────────
# Main pipeline
# ──────────────────────────────────────────────

def orchestrate_file(
    input_path: str,
    model_path: str,
    output_path: Optional[str] = None,
    model_size: str = 'base',
    threshold: float = 0.35,
    hop_s: float = HOP_S,
    device: Optional[str] = None,
    chunk_T: int = 2048,
) -> str:
    """
    Full pipeline: MusicXML → orchestrated MusicXML.

    Parameters
    ----------
    input_path  : path to input MusicXML (any complexity)
    model_path  : path to trained model checkpoint (.pt)
    output_path : where to write output (default: <input>_orchestrated.xml)
    model_size  : 'small' | 'base' | 'large'
    threshold   : activation threshold (0.35 default)
    hop_s       : frame hop in seconds (must match training)
    device      : 'cuda' | 'cpu' | None (auto)
    chunk_T     : process this many frames at a time (memory management)

    Returns
    -------
    str : path to the output MusicXML file
    """
    if output_path is None:
        stem   = Path(input_path).stem
        suffix = Path(input_path).suffix
        output_path = str(Path(input_path).parent / f'{stem}_orchestrated{suffix}')

    # ── Step 1: Parse ─────────────────────────────────────────────────────
    log.info(f'Parsing: {input_path}')
    parsed = parse_musicxml(input_path)
    log.info(
        f'  Title: "{parsed.title}"  Composer: "{parsed.composer}"  '
        f'Duration: {parsed.duration_s:.1f}s  Notes: {len(parsed.notes)}'
    )

    # ── Step 2: Piano roll ────────────────────────────────────────────────
    log.info('Extracting piano roll features…')
    roll, onset = score_to_pianoroll(parsed, hop_s=hop_s)
    T = roll.shape[0]
    log.info(f'  Piano roll: {roll.shape}  (T={T} frames, {T*hop_s:.1f}s)')

    # ── Step 3: Load model ────────────────────────────────────────────────
    model = load_model(model_path, model_size=model_size, device=device)
    dev   = next(model.parameters()).device

    # ── Step 4: Inference (chunked for long pieces) ───────────────────────
    log.info('Running orchestration inference…')
    roll_tensor = torch.from_numpy(roll).float().to(dev)   # (T, 128)

    from src.model import INST_NAMES, N_ORCH, N_PITCH

    # Collect activations across all chunks
    all_probs = torch.zeros(T, N_ORCH, N_PITCH, device='cpu')
    all_vels  = torch.zeros(T, N_ORCH, device='cpu')

    n_chunks  = max(1, (T + chunk_T - 1) // chunk_T)
    log.info(f'  Processing {n_chunks} chunk(s) of up to {chunk_T} frames…')

    for c in range(n_chunks):
        start = c * chunk_T
        end   = min(start + chunk_T, T)
        chunk = roll_tensor[start:end].unsqueeze(0)   # (1, C, 128)

        with torch.no_grad():
            logits, vels = model(chunk)               # (1, C, N_ORCH, 128), (1, C, N_ORCH)

        probs = torch.sigmoid(logits).squeeze(0).cpu()   # (C, N_ORCH, 128)
        vels  = vels.squeeze(0).cpu()                    # (C, N_ORCH)

        all_probs[start:end] = probs
        all_vels[start:end]  = vels

    # ── Step 5: Decode activations → note events ──────────────────────────
    log.info(f'Decoding at threshold={threshold}…')
    orch_notes = _decode_activations(all_probs, all_vels, threshold, hop_s)

    n_total = sum(len(v) for v in orch_notes.values())
    log.info(f'  Generated {n_total} orchestral notes across {len(INST_NAMES)} instruments')
    for name, notes in orch_notes.items():
        if notes:
            log.info(f'    {name:15s}: {len(notes)} notes')

    # ── Step 6: Write MusicXML ────────────────────────────────────────────
    log.info(f'Writing orchestral MusicXML: {output_path}')
    write_orchestral_musicxml(parsed, orch_notes, output_path, hop_s=hop_s)
    log.info('Done.')
    return output_path


def _decode_activations(
    probs: torch.Tensor,       # (T, N_ORCH, 128) on cpu
    vels: torch.Tensor,        # (T, N_ORCH)
    threshold: float,
    hop_s: float,
) -> dict:
    from src.model import INST_NAMES, N_PITCH
    T = probs.shape[0]
    result = {name: [] for name in INST_NAMES}

    probs_np = probs.numpy()   # (T, N_ORCH, 128)
    vels_np  = vels.numpy()    # (T, N_ORCH)

    for i_inst, name in enumerate(INST_NAMES):
        act = probs_np[:, i_inst, :] > threshold   # (T, 128) bool

        for pitch in range(N_PITCH):
            frames = act[:, pitch]
            in_note = False
            note_start_f = 0

            for f in range(T):
                if frames[f] and not in_note:
                    in_note = True
                    note_start_f = f
                elif not frames[f] and in_note:
                    in_note = False
                    onset_s  = note_start_f * hop_s
                    offset_s = f * hop_s
                    v = float(vels_np[note_start_f:f, i_inst].mean())
                    result[name].append((onset_s, offset_s, pitch, v))

            if in_note:
                onset_s  = note_start_f * hop_s
                offset_s = T * hop_s
                v = float(vels_np[note_start_f:, i_inst].mean())
                result[name].append((onset_s, offset_s, pitch, v))

    return result


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Orchestrate a MusicXML file using a trained OrchestraNet model.'
    )
    parser.add_argument('--input',      '-i', required=True,  help='Input MusicXML path')
    parser.add_argument('--model',      '-m', required=True,  help='Trained model checkpoint (.pt)')
    parser.add_argument('--output',     '-o', default=None,   help='Output MusicXML path')
    parser.add_argument('--model_size', default='base',       choices=['small','base','large'])
    parser.add_argument('--threshold',  type=float, default=0.35)
    parser.add_argument('--hop_s',      type=float, default=HOP_S)
    parser.add_argument('--device',     default=None,         help='cuda | cpu')
    parser.add_argument('--chunk_T',    type=int,   default=2048,
                        help='Frame chunk size for long pieces (memory management)')
    args = parser.parse_args()

    out = orchestrate_file(
        input_path  = args.input,
        model_path  = args.model,
        output_path = args.output,
        model_size  = args.model_size,
        threshold   = args.threshold,
        hop_s       = args.hop_s,
        device      = args.device,
        chunk_T     = args.chunk_T,
    )
    print(f'\nOrchestrated score written to: {out}')


if __name__ == '__main__':
    main()
