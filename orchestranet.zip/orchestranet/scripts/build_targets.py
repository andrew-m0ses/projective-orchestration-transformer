"""
build_targets.py
────────────────
Pre-compute per-(instrument, frame, pitch) binary activation targets from
the LOP orchestra MIDI files and save alongside the existing .npz features.

This script is run ONCE before training.

Usage:
  python scripts/build_targets.py \
      --data_root /path/to/AI-for-Projective-Musical-Orchestration-main

Output:
  data/features/orch_pitch/<pair_id_slug>.npz
    activations: (T, N_ORCH, 128) uint8
    velocities:  (T, N_ORCH)      float32

These are large arrays; for a 5-minute piece at 50ms hop:
  T ≈ 6000 frames × 15 instruments × 128 pitches × 1 byte ≈ 11.5 MB per piece.
We use uint8 (0/1) to keep memory manageable.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.dataset import GM_TO_ORCH
from src.model import N_ORCH, N_PITCH, INST_NAMES


def build_pitch_targets(orch_npz_path: Path) -> tuple[np.ndarray, np.ndarray]:
    """
    Load an orch .npz file and return:
      activations: (T, N_ORCH, 128) uint8
      velocities:  (T, N_ORCH)      float32
    """
    data = np.load(orch_npz_path)
    T = int(data['instrument_activity'].shape[0])

    activations = np.zeros((T, N_ORCH, N_PITCH), dtype=np.uint8)
    velocities  = np.zeros((T, N_ORCH),           dtype=np.float32)

    sparse_t = data['sparse_t']   # (K,) int32
    sparse_i = data['sparse_i']   # (K,) int16
    sparse_p = data['sparse_p']   # (K,) int16
    sparse_v = data['sparse_v']   # (K,) float32

    K = len(sparse_t)
    for k in range(K):
        t_frame  = int(sparse_t[k])
        gm_prog  = int(sparse_i[k])
        midi_p   = int(sparse_p[k])
        vel      = float(sparse_v[k])

        if t_frame >= T or not (0 <= midi_p < N_PITCH):
            continue
        orch_idx = int(GM_TO_ORCH[min(gm_prog, 128)])
        if orch_idx < 0:
            continue

        activations[t_frame, orch_idx, midi_p] = 1
        velocities[t_frame, orch_idx] = max(velocities[t_frame, orch_idx], vel)

    return activations, velocities


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_root', type=Path, required=True)
    parser.add_argument('--overwrite', action='store_true')
    args = parser.parse_args()

    data_root = args.data_root
    index_path = data_root / 'data' / 'features' / 'meta' / 'features_index.csv'
    df = pd.read_csv(index_path)

    out_dir = data_root / 'data' / 'features' / 'orch_pitch'
    out_dir.mkdir(parents=True, exist_ok=True)

    done = 0
    for _, row in df.iterrows():
        orch_path = data_root / row['orch_npz']
        if not orch_path.exists():
            continue

        slug = row['pair_id'].replace('/', '__')
        out_path = out_dir / f'{slug}.npz'
        if out_path.exists() and not args.overwrite:
            done += 1
            continue

        try:
            acts, vels = build_pitch_targets(orch_path)
            np.savez_compressed(out_path, activations=acts, velocities=vels)
            done += 1
            if done % 50 == 0:
                print(f'{done} / {len(df)} pairs processed…')
        except Exception as e:
            print(f'Error processing {orch_path}: {e}')

    print(f'Done. {done} target files written to {out_dir}')


if __name__ == '__main__':
    main()
