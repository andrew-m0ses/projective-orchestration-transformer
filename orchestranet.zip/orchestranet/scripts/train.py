"""
train.py
────────
Full training loop for OrchestraNet on the LOP database.

Usage:
  python train.py --data_root /path/to/AI-for-Projective-Musical-Orchestration-main \
                  --out_dir   runs/orchestranet_base \
                  --model_size base \
                  --epochs 100 \
                  --batch_size 16

Checkpoints, TensorBoard logs, and best-model weights are saved to --out_dir.
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from pathlib import Path
from typing import Dict

# Ensure the orchestranet project root (parent of this scripts/ folder) is on the path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

from src.model import OrchestraNet, build_model
from src.dataset import LOPDataset, load_manifest, pad_collate

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s  %(levelname)-8s  %(message)s',
    datefmt='%H:%M:%S',
)
log = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# Evaluation metrics
# ──────────────────────────────────────────────

def compute_metrics(
    logits: torch.Tensor,   # (B, T, N_ORCH, 128)
    targets: torch.Tensor,  # (B, T, N_ORCH, 128) binary
    threshold: float = 0.35,
) -> Dict[str, float]:
    """Compute frame-level precision, recall, F1 across all instruments."""
    probs = torch.sigmoid(logits).detach()
    preds = (probs > threshold).float()
    tgts  = targets.float()

    tp = (preds * tgts).sum()
    fp = (preds * (1 - tgts)).sum()
    fn = ((1 - preds) * tgts).sum()

    precision = (tp / (tp + fp + 1e-8)).item()
    recall    = (tp / (tp + fn + 1e-8)).item()
    f1        = 2 * precision * recall / (precision + recall + 1e-8)

    return {'precision': precision, 'recall': recall, 'f1': f1}


# ──────────────────────────────────────────────
# Training epoch
# ──────────────────────────────────────────────

def train_epoch(
    model: OrchestraNet,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    grad_clip: float = 1.0,
) -> Dict[str, float]:
    model.train()
    totals: Dict[str, float] = {}
    n = 0

    for piano_roll, target_acts, target_vels in loader:
        piano_roll  = piano_roll.to(device)
        target_acts = target_acts.to(device)
        target_vels = target_vels.to(device)

        optimizer.zero_grad(set_to_none=True)
        losses = model.compute_loss(piano_roll, target_acts, target_vels)
        losses['loss'].backward()

        if grad_clip > 0:
            nn.utils.clip_grad_norm_(model.parameters(), grad_clip)

        optimizer.step()

        for k, v in losses.items():
            totals[k] = totals.get(k, 0.0) + v.item()
        n += 1

    return {k: v / n for k, v in totals.items()}


@torch.no_grad()
def eval_epoch(
    model: OrchestraNet,
    loader: DataLoader,
    device: torch.device,
) -> Dict[str, float]:
    model.eval()
    totals: Dict[str, float] = {}
    n = 0

    for piano_roll, target_acts, target_vels in loader:
        piano_roll  = piano_roll.to(device)
        target_acts = target_acts.to(device)
        target_vels = target_vels.to(device)

        losses = model.compute_loss(piano_roll, target_acts, target_vels)
        logits, _ = model(piano_roll)
        metrics = compute_metrics(logits, target_acts)

        for k, v in {**losses, **metrics}.items():
            val = v.item() if hasattr(v, 'item') else v
            totals[k] = totals.get(k, 0.0) + val
        n += 1

    return {k: v / n for k, v in totals.items()}


# ──────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_root',   type=Path, required=True)
    parser.add_argument('--out_dir',     type=Path, default=Path('runs/orchestranet'))
    parser.add_argument('--model_size',  default='base', choices=['small','base','large'])
    parser.add_argument('--epochs',      type=int,   default=100)
    parser.add_argument('--batch_size',  type=int,   default=16)
    parser.add_argument('--segment_T',  type=int,   default=512,
                        help='Training segment length in frames (0 = whole piece)')
    parser.add_argument('--lr',          type=float, default=3e-4)
    parser.add_argument('--weight_decay',type=float, default=1e-2)
    parser.add_argument('--grad_clip',   type=float, default=1.0)
    parser.add_argument('--num_workers', type=int,   default=4)
    parser.add_argument('--threshold',   type=float, default=0.35)
    parser.add_argument('--resume',      type=Path,  default=None)
    parser.add_argument('--seed',        type=int,   default=42)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    log.info(f'Device: {device}')

    args.out_dir.mkdir(parents=True, exist_ok=True)

    # ── Data ──────────────────────────────────
    train_rows = load_manifest(args.data_root, split='train')
    valid_rows = load_manifest(args.data_root, split='valid')
    log.info(f'Train: {len(train_rows)} pairs  |  Valid: {len(valid_rows)} pairs')

    seg_T = args.segment_T if args.segment_T > 0 else None
    train_ds = LOPDataset(train_rows, args.data_root, segment_T=seg_T,  augment=True)
    valid_ds = LOPDataset(valid_rows, args.data_root, segment_T=seg_T, augment=False)

    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, collate_fn=pad_collate, pin_memory=True,
    )
    valid_loader = DataLoader(
        valid_ds, batch_size=args.batch_size, shuffle=False,
        num_workers=args.num_workers, collate_fn=pad_collate,
    )

    # ── Model ─────────────────────────────────
    model = build_model(args.model_size).to(device)
    model.threshold = args.threshold
    n_params = sum(p.numel() for p in model.parameters())
    log.info(f'Model: {args.model_size}  ({n_params/1e6:.1f}M params)')

    # ── Optimiser ─────────────────────────────
    optimizer = AdamW(
        model.parameters(),
        lr=args.lr, weight_decay=args.weight_decay,
    )
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=args.lr * 0.05)

    start_epoch = 0
    best_f1 = 0.0

    if args.resume:
        ckpt = torch.load(args.resume, map_location=device)
        model.load_state_dict(ckpt['model'])
        optimizer.load_state_dict(ckpt['optimizer'])
        scheduler.load_state_dict(ckpt['scheduler'])
        start_epoch = ckpt['epoch'] + 1
        best_f1 = ckpt.get('best_f1', 0.0)
        log.info(f'Resumed from epoch {start_epoch}')

    # ── TensorBoard (optional) ────────────────
    try:
        from torch.utils.tensorboard import SummaryWriter
        writer = SummaryWriter(args.out_dir / 'tb')
    except ImportError:
        writer = None

    # ── Training loop ─────────────────────────
    for epoch in range(start_epoch, args.epochs):
        t0 = time.time()

        train_stats = train_epoch(model, train_loader, optimizer, device, args.grad_clip)
        valid_stats = eval_epoch(model, valid_loader, device)
        scheduler.step()

        elapsed = time.time() - t0
        log.info(
            f'Epoch {epoch:03d}  '
            f'train_loss={train_stats["loss"]:.4f}  '
            f'val_loss={valid_stats["loss"]:.4f}  '
            f'val_f1={valid_stats["f1"]:.4f}  '
            f'({elapsed:.0f}s)'
        )

        if writer:
            for k, v in train_stats.items():
                writer.add_scalar(f'train/{k}', v, epoch)
            for k, v in valid_stats.items():
                writer.add_scalar(f'valid/{k}', v, epoch)
            writer.add_scalar('lr', scheduler.get_last_lr()[0], epoch)

        # Save latest checkpoint
        ckpt = {
            'epoch':     epoch,
            'model':     model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'scheduler': scheduler.state_dict(),
            'best_f1':   best_f1,
            'args':      vars(args),
        }
        torch.save(ckpt, args.out_dir / 'last.pt')

        # Save best model
        if valid_stats['f1'] > best_f1:
            best_f1 = valid_stats['f1']
            torch.save(ckpt, args.out_dir / 'best.pt')
            log.info(f'  ✓ New best F1: {best_f1:.4f}')

    log.info('Training complete.')
    if writer:
        writer.close()


if __name__ == '__main__':
    main()
