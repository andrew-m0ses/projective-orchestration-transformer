"""
augment_lop.py
──────────────
Augment the LOP database by applying identical transformations to each
piano/orchestra MIDI pair, producing new paired MIDI files and corresponding
.npz feature files ready for training.

Augmentations applied (always identically to both piano AND orchestra):
  1. Pitch shift:    -6, -5, -4, -3, -2, -1, +1, +2, +3, +4, +5, +6 semitones
                     (skipping shifts that push any note out of MIDI 0-127)
  2. Velocity scale: 0.75, 0.85, 1.15, 1.25
                     (applied to both piano and orchestra identically)

Each original pair produces up to 12 pitch variants × 4 velocity variants = 48
augmented pairs, plus the original = up to 49 pairs per original.

With 196 originals → up to ~9,600 training pairs total.

Usage (run in Colab after uploading):
  python scripts/augment_lop.py --data_root /path/to/LOP_database_root

Output:
  data/augmented/
    <source>/<pair_idx>_ps<shift>_vs<scale>/
      piano.mid
      orch.mid
  data/features/piano_aug/<slug>.npz
  data/features/orch_aug/<slug>.npz
  data/features/meta/features_index_aug.csv   (full index including augmented)
"""
from __future__ import annotations

import argparse
import os
import sys
import warnings
from pathlib import Path
from typing import List, Optional, Tuple

warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import pretty_midi

# ── Make src importable ───────────────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.features.piano import extract_piano_features, piano_features_to_npz_dict
from src.features.orch  import extract_orch_features,  orch_features_to_npz_dict


# ──────────────────────────────────────────────────────────────────────────
# Augmentation parameters
# ──────────────────────────────────────────────────────────────────────────

PITCH_SHIFTS   = [-6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6]
VEL_SCALES     = [0.75, 0.85, 1.15, 1.25]
HOP_S          = 0.05


# ──────────────────────────────────────────────────────────────────────────
# MIDI augmentation helpers
# ──────────────────────────────────────────────────────────────────────────

def _pitch_shift_midi(pm: pretty_midi.PrettyMIDI, semitones: int) -> Optional[pretty_midi.PrettyMIDI]:
    """
    Return a new PrettyMIDI with all notes shifted by `semitones`.
    Returns None if any note would go out of range 0-127.
    Drums are NOT shifted (channel 9 / is_drum=True).
    """
    out = pretty_midi.PrettyMIDI(initial_tempo=_get_initial_tempo(pm))

    for inst in pm.instruments:
        new_inst = pretty_midi.Instrument(
            program=inst.program,
            is_drum=inst.is_drum,
            name=inst.name,
        )
        for note in inst.notes:
            if inst.is_drum:
                new_pitch = note.pitch
            else:
                new_pitch = note.pitch + semitones
                if not (0 <= new_pitch <= 127):
                    return None  # out of range — skip this shift entirely
            new_note = pretty_midi.Note(
                velocity=note.velocity,
                pitch=new_pitch,
                start=note.start,
                end=note.end,
            )
            new_inst.notes.append(new_note)
        new_inst.control_changes = inst.control_changes
        out.instruments.append(new_inst)

    # Copy tempo / time signature / key signature
    _copy_meta(pm, out)
    return out


def _velocity_scale_midi(pm: pretty_midi.PrettyMIDI, scale: float) -> pretty_midi.PrettyMIDI:
    """
    Return a new PrettyMIDI with all note velocities scaled by `scale`.
    Clips to [1, 127].
    """
    out = pretty_midi.PrettyMIDI(initial_tempo=_get_initial_tempo(pm))

    for inst in pm.instruments:
        new_inst = pretty_midi.Instrument(
            program=inst.program,
            is_drum=inst.is_drum,
            name=inst.name,
        )
        for note in inst.notes:
            new_vel = int(np.clip(round(note.velocity * scale), 1, 127))
            new_note = pretty_midi.Note(
                velocity=new_vel,
                pitch=note.pitch,
                start=note.start,
                end=note.end,
            )
            new_inst.notes.append(new_note)
        new_inst.control_changes = inst.control_changes
        out.instruments.append(new_inst)

    _copy_meta(pm, out)
    return out


def _get_initial_tempo(pm: pretty_midi.PrettyMIDI) -> float:
    times, tempos = pm.get_tempo_changes()
    return float(tempos[0]) if len(tempos) > 0 else 120.0


def _copy_meta(src: pretty_midi.PrettyMIDI, dst: pretty_midi.PrettyMIDI):
    """Copy tempo changes, time signatures, key signatures from src to dst."""
    # pretty_midi stores these internally — easiest to re-parse from the
    # underlying mido object, but PrettyMIDI doesn't expose that directly.
    # Instead we copy the arrays pretty_midi already parsed.
    dst._tick_scales = src._tick_scales
    dst.time_signature_changes = src.time_signature_changes
    dst.key_signature_changes  = src.key_signature_changes


def _check_range(pm: pretty_midi.PrettyMIDI) -> bool:
    """Return True if all non-drum pitches are in [0, 127]."""
    for inst in pm.instruments:
        if inst.is_drum:
            continue
        for note in inst.notes:
            if not (0 <= note.pitch <= 127):
                return False
    return True


# ──────────────────────────────────────────────────────────────────────────
# Path resolution
# ──────────────────────────────────────────────────────────────────────────

def _resolve_midi_path(manifest_path: str, data_root: Path) -> Optional[Path]:
    """
    The manifest stores absolute paths from the original developer's machine.
    We reconstruct the relative portion starting from 'LOP_database_06_09_17'.
    """
    marker = 'LOP_database_06_09_17'
    if marker in manifest_path:
        rel = manifest_path[manifest_path.index(marker):]
        candidate = data_root / 'data' / 'raw' / rel
        if candidate.exists():
            return candidate
    # Fallback: try just the filename in the pair dir
    return None


# ──────────────────────────────────────────────────────────────────────────
# Feature extraction wrapper
# ──────────────────────────────────────────────────────────────────────────

def _extract_and_save_features(
    midi_path: Path,
    npz_path: Path,
    kind: str,  # 'piano' or 'orch'
):
    """Extract features from a MIDI file and save as .npz."""
    try:
        if kind == 'piano':
            feats = extract_piano_features(str(midi_path), hop_s=HOP_S)
            np.savez_compressed(npz_path, **piano_features_to_npz_dict(feats))
        else:
            feats = extract_orch_features(str(midi_path), hop_s=HOP_S)
            np.savez_compressed(npz_path, **orch_features_to_npz_dict(feats))
        return True
    except Exception as e:
        print(f'      Feature extraction failed for {midi_path.name}: {e}')
        return False


# ──────────────────────────────────────────────────────────────────────────
# Main augmentation loop
# ──────────────────────────────────────────────────────────────────────────

def augment_dataset(
    data_root: Path,
    limit: int = 0,
    skip_existing: bool = True,
    extract_features: bool = True,
):
    manifest_path = data_root / 'data' / 'processed' / 'lop_manifest.parquet'
    if not manifest_path.exists():
        raise FileNotFoundError(f'Manifest not found: {manifest_path}')

    df = pd.read_parquet(manifest_path)
    # Only process usable pairs
    usable = df[df['usable'] == True].copy() if 'usable' in df.columns else df.copy()
    print(f'Total usable pairs: {len(usable)}')

    if limit > 0:
        usable = usable.head(limit)
        print(f'Limited to {limit} pairs for testing')

    # Output directories
    aug_midi_dir   = data_root / 'data' / 'augmented'
    piano_npz_dir  = data_root / 'data' / 'features' / 'piano_aug'
    orch_npz_dir   = data_root / 'data' / 'features' / 'orch_aug'
    for d in [aug_midi_dir, piano_npz_dir, orch_npz_dir]:
        d.mkdir(parents=True, exist_ok=True)

    index_rows = []
    total_generated = 0
    total_skipped   = 0
    total_failed    = 0

    for row_idx, (_, row) in enumerate(usable.iterrows()):
        pair_id  = row['pair_id']
        source   = row['source']
        pair_idx = row['pair_index']

        print(f'\n[{row_idx+1}/{len(usable)}] {pair_id}')

        # Resolve MIDI paths
        piano_path = _resolve_midi_path(str(row['piano_midi']), data_root)
        orch_path  = _resolve_midi_path(str(row['orch_midi']),  data_root)

        if piano_path is None or orch_path is None:
            print(f'  ⚠ Could not resolve MIDI paths — skipping')
            print(f'    piano: {row["piano_midi"]}')
            print(f'    orch:  {row["orch_midi"]}')
            total_failed += 1
            continue

        # Load MIDIs
        try:
            piano_pm = pretty_midi.PrettyMIDI(str(piano_path))
            orch_pm  = pretty_midi.PrettyMIDI(str(orch_path))
        except Exception as e:
            print(f'  ⚠ Could not load MIDI: {e}')
            total_failed += 1
            continue

        # ── Pitch shifts ────────────────────────────────────────────────
        for shift in PITCH_SHIFTS:
            slug = f'{source}__{pair_idx}_ps{shift:+d}'
            out_dir = aug_midi_dir / slug
            piano_out = out_dir / 'piano.mid'
            orch_out  = out_dir / 'orch.mid'

            if skip_existing and piano_out.exists() and orch_out.exists():
                total_skipped += 1
                # Still add to index
                index_rows.append(_make_index_row(
                    slug, pair_id, source, shift, 1.0,
                    piano_npz_dir, orch_npz_dir
                ))
                continue

            # Apply SAME shift to both
            new_piano = _pitch_shift_midi(piano_pm, shift)
            new_orch   = _pitch_shift_midi(orch_pm,  shift)

            if new_piano is None or new_orch is None:
                print(f'  ⚠ Pitch shift {shift:+d}: out of range — skipping')
                continue

            out_dir.mkdir(parents=True, exist_ok=True)
            new_piano.write(str(piano_out))
            new_orch.write(str(orch_out))

            # Extract features
            if extract_features:
                piano_npz = piano_npz_dir / f'{slug}.npz'
                orch_npz  = orch_npz_dir  / f'{slug}.npz'
                ok_p = _extract_and_save_features(piano_out, piano_npz, 'piano')
                ok_o = _extract_and_save_features(orch_out,  orch_npz,  'orch')
                if not (ok_p and ok_o):
                    total_failed += 1
                    continue

            index_rows.append(_make_index_row(
                slug, pair_id, source, shift, 1.0,
                piano_npz_dir, orch_npz_dir
            ))
            total_generated += 1
            print(f'  ✓ pitch {shift:+d}')

            # ── Velocity scales on top of pitch shift ────────────────
            for vscale in VEL_SCALES:
                vslug = f'{slug}_vs{int(vscale*100)}'
                vout_dir = aug_midi_dir / vslug
                vp_out = vout_dir / 'piano.mid'
                vo_out = vout_dir / 'orch.mid'

                if skip_existing and vp_out.exists() and vo_out.exists():
                    total_skipped += 1
                    index_rows.append(_make_index_row(
                        vslug, pair_id, source, shift, vscale,
                        piano_npz_dir, orch_npz_dir
                    ))
                    continue

                vp = _velocity_scale_midi(new_piano, vscale)
                vo = _velocity_scale_midi(new_orch,  vscale)

                vout_dir.mkdir(parents=True, exist_ok=True)
                vp.write(str(vp_out))
                vo.write(str(vo_out))

                if extract_features:
                    vnpz_p = piano_npz_dir / f'{vslug}.npz'
                    vnpz_o = orch_npz_dir  / f'{vslug}.npz'
                    ok_p = _extract_and_save_features(vp_out, vnpz_p, 'piano')
                    ok_o = _extract_and_save_features(vo_out, vnpz_o, 'orch')
                    if not (ok_p and ok_o):
                        total_failed += 1
                        continue

                index_rows.append(_make_index_row(
                    vslug, pair_id, source, shift, vscale,
                    piano_npz_dir, orch_npz_dir
                ))
                total_generated += 1

        # ── Velocity-only variants (no pitch shift) ──────────────────
        for vscale in VEL_SCALES:
            slug = f'{source}__{pair_idx}_vs{int(vscale*100)}'
            out_dir = aug_midi_dir / slug
            piano_out = out_dir / 'piano.mid'
            orch_out  = out_dir / 'orch.mid'

            if skip_existing and piano_out.exists() and orch_out.exists():
                total_skipped += 1
                index_rows.append(_make_index_row(
                    slug, pair_id, source, 0, vscale,
                    piano_npz_dir, orch_npz_dir
                ))
                continue

            vp = _velocity_scale_midi(piano_pm, vscale)
            vo = _velocity_scale_midi(orch_pm,  vscale)

            out_dir.mkdir(parents=True, exist_ok=True)
            vp.write(str(piano_out))
            vo.write(str(orch_out))

            if extract_features:
                piano_npz = piano_npz_dir / f'{slug}.npz'
                orch_npz  = orch_npz_dir  / f'{slug}.npz'
                ok_p = _extract_and_save_features(piano_out, piano_npz, 'piano')
                ok_o = _extract_and_save_features(orch_out,  orch_npz,  'orch')
                if not (ok_p and ok_o):
                    total_failed += 1
                    continue

            index_rows.append(_make_index_row(
                slug, pair_id, source, 0, vscale,
                piano_npz_dir, orch_npz_dir
            ))
            total_generated += 1
            print(f'  ✓ vel {vscale}')

    # ── Save augmented index ─────────────────────────────────────────────
    if index_rows:
        aug_df = pd.DataFrame(index_rows)
        aug_index_path = data_root / 'data' / 'features' / 'meta' / 'features_index_aug.csv'
        aug_df.to_csv(aug_index_path, index=False)
        print(f'\n✅ Augmented index saved: {aug_index_path}  ({len(aug_df)} rows)')

    print(f'\n─────────────────────────────────────────')
    print(f'Generated : {total_generated}')
    print(f'Skipped   : {total_skipped} (already existed)')
    print(f'Failed    : {total_failed}')
    print(f'Total aug : {total_generated + total_skipped}')


def _make_index_row(
    slug, pair_id, source, pitch_shift, vel_scale,
    piano_npz_dir, orch_npz_dir,
):
    return {
        'pair_id':      f'aug/{slug}',
        'source':       source,
        'orig_pair_id': pair_id,
        'pitch_shift':  pitch_shift,
        'vel_scale':    vel_scale,
        'piano_npz':    str(piano_npz_dir / f'{slug}.npz'),
        'orch_npz':     str(orch_npz_dir  / f'{slug}.npz'),
    }


# ──────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Augment the LOP MIDI dataset with pitch shifts and velocity scaling.'
    )
    parser.add_argument('--data_root', type=Path, required=True,
                        help='Path to AI-for-Projective-Musical-Orchestration-main/')
    parser.add_argument('--limit', type=int, default=0,
                        help='Process only this many pairs (0 = all). Use for testing.')
    parser.add_argument('--no_skip', action='store_true',
                        help='Re-generate even if output files already exist')
    parser.add_argument('--no_features', action='store_true',
                        help='Write MIDI files only, skip feature extraction')
    args = parser.parse_args()

    augment_dataset(
        data_root        = args.data_root,
        limit            = args.limit,
        skip_existing    = not args.no_skip,
        extract_features = not args.no_features,
    )
