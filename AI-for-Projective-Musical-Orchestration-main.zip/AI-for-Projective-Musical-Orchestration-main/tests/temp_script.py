import numpy as np
d = np.load("data/features/piano/bouliane__0.npz")
print(d.files)
